# Skripte generieren
# Aufruf mit Rscript: Verzeichnis, wo Befehl aufgerufen wird, ist wd, 
# nicht der Skript-Ort selbst

#geschätzte Laufzeit: 12 Instanzen * 4 Algos * 10 reps * 900 Sek
# 8 Kerne

ALL_FILES <- list.files("./instances")

for (fileName in ALL_FILES){
  cat(".")
  for (runNumber in 1:10){
    
    ####################################
    # HVNS und HVNS-T
    # nIter = 135456
    # endTemperatureFactor = 0.876
    ####################################
    
    fileContent <- paste("
       library(TwoMachineFlowShop)
       fileName <- \"", fileName, "\"
       filePath <- paste(\"./instances/\", fileName, sep=\"\")
       jobData <- read.csv(filePath, stringsAsFactors = F)
       fileData <- parseFlowShopName(fileName)
       bufferType <- \"intermediateBuffer\"
       if (fileData[\"bufferType\"] == \"f2total\"){
        bufferType <- \"totalBuffer\"
       } 
       bufSize <- fileData[\"maxBufferSize\"]
                         
      startHVNS(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, targetCriterion = \"makespan\", ", runNumber, ", \"\")
      
      startHVNSWithParameters(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, targetCriterion = \"makespan\", ", runNumber, ", \"tuned\",
      nIter=132456, endTemperatureFactor = 0.876)

    ", sep="")
    
    
    scriptName <- paste("./scripts/", fileName, "-hvns-", runNumber, ".R", sep="")
    write(scriptName, file="listOfScripts", append = T)
    write(fileContent, file=scriptName)
    
    ####################################
    # DABC und DABC-T
    # populationSize = 7
    # perturbationStrength = 7
    # destructionSize1 = 7
    # destructionSize2 = 4
    # numberOfInserts = 52
    # localSearchAttempts = 51
    ####################################
    
    fileContent <- paste("
    library(TwoMachineFlowShop)
    fileName <- \"", fileName, "\"
    filePath <- paste(\"./instances/\", fileName, sep=\"\")
    jobData <- read.csv(filePath, stringsAsFactors = F)
    fileData <- parseFlowShopName(fileName)
    bufferType <- \"intermediateBuffer\"
    if (fileData[\"bufferType\"] == \"f2total\"){
      bufferType <- \"totalBuffer\"
    }

    startDABC(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, \"makespan\", ", runNumber, ", \"\")
      
    startDABCWithParameters(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, \"makespan\", ", runNumber, ", \"tuned\",
      populationSize=7,
	  perturbationStrength=7,
	  destructionSize1=7,
	  destructionSize2=4,
	  numberOfInserts=52,
	  localSearchAttempts=51)
    ", sep="")

    scriptName <- paste("./scripts/", fileName, "-dabc-", runNumber, ".R", sep="")
    write(scriptName, file="listOfScripts", append = T)
    write(fileContent, file=scriptName)
    
    ####################################
    # ILS-cut
    # p = 0.24
    # operationSequence = 213
    # withReconstruct = 0
    ####################################
    
    fileContent <- paste("
       library(TwoMachineFlowShop)
       fileName <- \"", fileName, "\"
       filePath <- paste(\"./instances/\", fileName, sep=\"\")
       jobData <- read.csv(filePath, stringsAsFactors = F)
       fileData <- parseFlowShopName(fileName)
       bufferType <- \"intermediateBuffer\"
       if (fileData[\"bufferType\"] == \"f2total\"){
        bufferType <- \"totalBuffer\"
       }
       bufSize <- fileData[\"maxBufferSize\"]
 
      startILS(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, targetCriterion = \"makespan\", ", runNumber, ", \"cut\",
      lookAround=0, p=0.24, operationSequence=\"213\",
      withLS = TRUE, withReconstruct = FALSE,
      useRandomPermutationForLS = TRUE,
      withInitialReconstruct=FALSE)
    ", sep="")
    
    
    scriptName <- paste("./scripts/", fileName, "-ils-", runNumber, ".R", sep="")
    write(scriptName, file="listOfScripts", append = T)
    write(fileContent, file=scriptName)
    
    ####################################
    # ACOLS-lowEva
	# p = 0.914                 
    # operationSequence = "312"  
    # withReconstruct = 0       
    # numberOfAnts = 19         
    # evaporation = 0.018  
    ####################################
    
    fileContent <- paste("
       library(TwoMachineFlowShop)
       fileName <- \"", fileName, "\"
       filePath <- paste(\"./instances/\", fileName, sep=\"\")
       jobData <- read.csv(filePath, stringsAsFactors = F)
       fileData <- parseFlowShopName(fileName)
       bufferType <- \"intermediateBuffer\"
       if (fileData[\"bufferType\"] == \"f2total\"){
        bufferType <- \"totalBuffer\"
       }
       bufSize <- fileData[\"maxBufferSize\"]

      startACOLS(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, targetCriterion = \"makespan\", ", runNumber, ", \"lowEva\",
      lookAround=0, p=0.914, operationSequence=\"312\",
      withLS=TRUE, withReconstruct=FALSE,
      numberOfAnts=19, evaporation = 0.018)
    ", sep="")
    
    
    scriptName <- paste("./scripts/", fileName, "-acols-", runNumber, ".R", sep="")
    write(scriptName, file="listOfScripts", append = T)
    write(fileContent, file=scriptName)
    
  }
}
  

