# Skripte generieren
# Aufruf mit Rscript: Verzeichnis, wo Befehl aufgerufen wird, ist wd, 
# nicht der Skript-Ort selbst

#geschätzte Laufzeit: 12 Instanzen * 4 Algos * 10 reps * 900 Sek
# 8 Kerne

ALL_FILES <- list.files("./instances")

for (fileName in ALL_FILES){
  cat(".")
 
	############################
	########### NEH ############
	############################
	# Dataframe exportieren mit: Zeit, Evals, Quality

	fileContent <- paste("
	  library(TwoMachineFlowShop)
	  fileName <- \"", fileName, "\"
	  filePath <- paste(\"./instances/\", fileName, sep=\"\")
	  jobData <- read.csv(filePath, stringsAsFactors = F)
	  fileData <- parseFlowShopName(fileName)
	  bufferType <- \"intermediateBuffer\"
	  if (fileData[\"bufferType\"] == \"f2total\"){
		bufferType <- \"totalBuffer\"
	  }
	  maxBufferSize <- as.integer(fileData[\"maxBufferSize\"])
	  times <- c()
	  for(i in 1:10){
		times <- c(times, getNEHTime(jobData, bufferType,maxBufferSize,0))
	  }
	  
		times <- c(times, getNEHEvaluations(jobData))
		perm <- getNEHSolution(jobData, bufferType,maxBufferSize,0)
		perm <- paste(\"j\", perm, sep=\"\")

		if (bufferType == \"totalBuffer\"){
			quality <- simulateFlowShopTotalBufferC(jobData, perm, perm, maxBufferSize, TRUE)
		} else {
			quality <- simulateFlowShopC(jobData, perm, perm, maxBufferSize, TRUE)
		}
		times <- c(times, quality)
		  
		write(times, paste(\"./output/\", fileName, \"-neh\", sep=\"\"), ncolumns = 1)
	", sep="")

	scriptName <- paste("./scripts/", fileName, "-neh",  ".R", sep="")
	write(scriptName, file="listOfScripts", append = T)
	write(fileContent, file=scriptName)
    
}
  

