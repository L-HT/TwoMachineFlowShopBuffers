# Skripte generieren
# Aufruf mit Rscript: Verzeichnis, wo Befehl aufgerufen wird, ist wd, 
# nicht der Skript-Ort selbst

#geschätzte Laufzeit: 12 Instanzen * 4 Algos * 10 reps * 900 Sek
# 8 Kerne

ALL_FILES <- list.files("./instances")

for (fileName in ALL_FILES){
  cat(".")
  for (runNumber in 1:10){
   
    ####################################
    # ILS und ILS-cut
    # p = 0.240
    # operationSequence = "213"
    # withReconstruct = 0
    ####################################
    
    fileContent <- paste("
       library(TwoMachineFlowShop)
       fileName <- \"", fileName, "\"
       filePath <- paste(\"./instances/\", fileName, sep=\"\")
       jobData <- read.csv(filePath, stringsAsFactors = F)
       fileData <- parseFlowShopName(fileName)
       bufferType <- \"intermediateBuffer\"
       if (fileData[\"bufferType\"] == \"f2total\"){
        bufferType <- \"totalBuffer\"
       }
       bufSize <- fileData[\"maxBufferSize\"]

      startILS(jobData, fileName,
      as.integer(fileData[\"maxBufferSize\"]),
      bufferType, targetCriterion = \"makespan\", ", runNumber, ", \"cut\",
      lookAround=0, p=0.24, operationSequence=\"213\",
      withLS = TRUE, withReconstruct = FALSE,
      useRandomPermutationForLS = TRUE,
      withInitialReconstruct=FALSE)
    ", sep="")
    
    #startILS(jobData, "ils", maxBufferSize = maxBufferSize,
    #         "totalBuffer", runNumber = 100,
    #         lookAround = 0, p = 0.9, operationSequence = "2",
    #         numberOfAnts = 10, withACO = FALSE, withLS = TRUE,
    #         withReconstruct = FALSE
    #)
    
    scriptName <- paste("./scriptsILS/", fileName, "-ils-", runNumber, ".R", sep="")
    write(scriptName, file="listOfScripts", append = T)
    write(fileContent, file=scriptName)
  }
	
    
}
  

