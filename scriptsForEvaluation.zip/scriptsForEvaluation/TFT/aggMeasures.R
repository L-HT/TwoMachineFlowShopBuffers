# aggregative Maße nehmen:
# Mittelwerte für jede Tabelle bilden

pcFE <- read.csv("pcFE_rank.csv", check.names = F)
pcNT <- read.csv("pcNT_rank.csv", check.names = F)

ertFE <- read.csv("ertFE_rank.csv", check.names = F)
ertNT <- read.csv("ertNT_rank.csv", check.names = F)

ecdfFE <- read.csv("ecdfFE_rank.csv", check.names = F)
ecdfNT <- read.csv("ecdfNT_rank.csv", check.names = F)


df_list <- list(pcFE, pcNT, ertFE, ertNT, ecdfFE, ecdfNT)
meanDf <- data.frame("criteria" = c("pcFE", "pcNT", "ertFE", "ertNT", "ecdfFE", "ecdfNT"),
                     "acols-lowEva"=0,
                     "hvns"=0,
                     "dabc"=0,
                     "ils-cut"=0)

for (k in 1:length(df_list)){
  myDf <- df_list[[k]]
  myDf <- myDf[!is.na(myDf$acols.lowEva),]
  avgRanks <- apply(myDf[,-1], 2, FUN = mean)
  meanDf[k,-1] <- avgRanks
}

write.csv(meanDf, "meanRanks.csv", quote=F, row.names=F)

