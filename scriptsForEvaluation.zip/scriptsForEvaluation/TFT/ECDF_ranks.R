# Fläche von ECDF berechnen und Ranking bilden


algorithms <- c("sppbo", "sppbo-noh", "avi", "avi-norl", "api", "api-norl")

instanceNames <- list.files("./instancesClean")
instanceTypes <- c()
for (i in instanceNames){
  instanceTypes <- c(instanceTypes, getTypeOfInstance(i))
}
instanceTypeDf <- data.frame(name = instanceNames, type = instanceTypes)


instanceNames <- list.files("./instances")
timeMeasures <- c("NT","FE")
algorithms <- c("api","hvns","dabc","sppbo","avi","sppbo-noh","avi-norl","api-norl")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")


for (tm in timeMeasures){
  ecdfFiles <- list.files(paste("./ecdfTables",tm,sep=""))
  
  # Data Frame initialisieren
  resultDf <- data.frame(instance = ecdfFiles)
  i <- 1
  for (algo in algorithms){
    resultDf <- cbind(resultDf, 1)
    colnames(resultDf)[i+1] <- algo
    i <- i + 1
  }
  
  
  for (f in ecdfFiles){
    test <- read.csv(paste("./ecdfTables",tm,"/",f,sep=""))
    sums <- apply(test[,2:ncol(test)],MARGIN = 2,FUN=sum)
    ranks <- rank(-sums)
    names(ranks) <- algorithms
    
    for (algo in algorithms){
      resultDf[resultDf$instance == f, algo] <- ranks[algo] 
     
    }
    
  }
  #write.csv(resultDf, paste("ecdfArea",tm,sep=""),row.names=F)
  write.csv(resultDf, paste("ecdfRanks",tm,sep=""),row.names=F)
}
