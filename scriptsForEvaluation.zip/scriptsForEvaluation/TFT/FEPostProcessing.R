# HVNS, API, AVI, DABC nutzen NEH-Heuristik zur Initialisierung der Lösung
# die Lösungsevaluationsn sollten mitgezählt werden

# Wie viele Funktionsevaluationen gibt es bei einem NEH-Durchlauf?
# zu erst 2, dann 3, dann 4, usw... bis N

# und das so oft, wie NEH aufgerufen wird
# also: 2+3+...+N = ((N+1)*N/2) - 1
# für DABC: wird das 50 Mal gemacht, also kommt da einiges zusammen
instances <- list.files("./FE")
f <- instances[1]

for (f in instances){
  N <- parseInstanceName(f)$numberOfJobs
  test <- c()
  if (grepl("api",f)){
    test <- read.csv(paste("./FE/",f, sep=""), header=T)
    test$evaluation <- test$evaluation + ((N+1)*N/2)-1
  }
  if (grepl("avi",f)){
    test <- read.csv(paste("./FE/",f, sep=""), header=T)
    test$evaluation <- test$evaluation + ((N+1)*N/2)-1
  }
  if (grepl("hvns",f)){
    test <- read.csv(paste("./FE/",f, sep=""), header=T)
    test$evaluation <- test$evaluation + ((N+1)*N/2)-1
  }
  if (grepl("dabc",f)){
    test <- read.csv(paste("./FE/",f, sep=""), header=T)
    test$evaluation <- test$evaluation + 50*(((N+1)*N/2)-1)
  }
  if (grepl("sppbo",f)){
    next
  }
  write.csv(test, paste("./FE/",f, sep=""), row.names=F)
  cat(".")
}
