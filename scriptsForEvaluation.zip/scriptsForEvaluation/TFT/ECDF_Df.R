# ECDF in Tabellen speichern

parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
  )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  
  return(parts)
}
algoToColor <- function(algo){
  colorArray <- c("green","violet","red","orange","brown")
  for (i in 1:length(algorithms)){
    if (algo == algorithms[i]){
      return(colorArray[i])
    }
  }
  return("black")
}

instanceNames <- list.files("./instances")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")
nehTimes <- read.csv("nehTimes.csv")

startTime <- Sys.time()
for (f in instanceNames){
  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
  goalValue <- ceiling(optimalTime * 1.01)
  instanceData <- parseInstanceName(f)
  
  for (tm in timeMeasures){
    ecdfCounter <- 1
    rightLimit <- 0
    
    #######################
    # rightLimit bestimmen
    #######################
    
    for (algo in algorithms){
      for (run in 1:numberOfRuns){
        fileName <- paste("./COMBINEDRESULTS/",f,"-",algo,"-",run,sep="")

        test <- read.csv(fileName,stringsAsFactors = F, header=F)
        
        if (tm == "AT"){
          test <- test[,c(2,4)]
        }
        if (tm == "NT"){
          test <- test[,c(2,4)]
          test[,1] <- test[,1] / nehTimes[nehTimes$instanceNames == f,2]
        }
        if (tm == "FE"){
          test <- test[,c(1,4)]
        }
        maxTime <- test[nrow(test),1]
        if (maxTime > rightLimit){
          rightLimit <- maxTime
        }
      }
    }
    ##############################################
    # eigentliches ECDF berechnen
    ##############################################
    
    detail <- 250
    xSeq <- ceiling(seq(0,rightLimit,length.out = detail))
    ecdf_df <- data.frame(xSeq)
    colnames(ecdf_df)[1] <- tm
    ecdfCounter <- 1
    
    for (algo in algorithms){
      algoDfs <- list()
      currentEcdf <- c()
      for (run in 1:numberOfRuns){
        fileName <- paste("./COMBINEDRESULTS/",f,"-",algo,"-",run,sep="")
        test <- read.csv(fileName,stringsAsFactors = F, header=F)
        
        if (tm == "AT"){
          test <- test[,c(2,4)]
        }
        if (tm == "NT"){
          test <- test[,c(2,4)]
          test[,1] <- test[,1] / nehTimes[nehTimes$instanceNames == f,2]
        }
        if (tm == "FE"){
          test <- test[,c(1,4)]
        }
        algoDfs[[run]] <- test
      }
      currentEcdf <- rep(0, detail)
      i <- 1
      for (x in xSeq){
        successes <- 0
        for (run in 1:numberOfRuns){
          test <- algoDfs[[run]]
          valuesReached <- test[test[,1] <= x,2]
          if (length(valuesReached) > 0){
            if (valuesReached[length(valuesReached)] <= goalValue){
              successes <- successes + 1
            }
          } else {
            # wenn kein Wert in diesem Zeitfenster existiert, ist das auch kein Erfolg
            # also auch nicht hochzählen
          }
        }
        currentEcdf[i] <- successes/numberOfRuns
        i <- i + 1
      }
      ecdf_df <- cbind(ecdf_df, currentEcdf)
      colnames(ecdf_df)[ecdfCounter + 1] <- algo
      ecdfCounter <- ecdfCounter + 1
    }

    ##########################
    # Schreiben
    ##########################
    
    write.csv(ecdf_df, paste("./ecdfTables",tm,"/",f,sep=""), row.names=F)
    cat(".")
  }
}
print(Sys.time()-startTime)
