# Estimated Run-Time aufzeichnen und in Tabellen speichern

parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
  )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  
  return(parts)
}

# AT

instanceNames <- list.files("./instances")


kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")

for (f in instanceNames){
  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
  for (tm in timeMeasures){
    dfs <- list()
    i <- 1
    worstRel <- 0
    for (algo in algorithms){
      fileName <- paste("./",tm,"/",f,"-",algo,sep="")
      test <- read.csv(fileName,stringsAsFactors = F, header=T)
      test$makespan <- (test$makespan - optimalTime)/optimalTime
      if (test$makespan[1] > worstRel){
        worstRel <- test$makespan[1]
      }
      dfs[[i]] <- test
      i <- i +1
    }
    worstRel <- min(worstRel, 10)
    xSeq <- seq(from=worstRel, to=0, length.out=100)
    ert <- list()
    highest <- 0
    for (i in 1:length(algorithms)){
      tempRes <- rep(0,length(xSeq))
      j <- length(xSeq)
      for (x in xSeq){
        test <- dfs[[i]]
        test <- (test[test$makespan <= x,1])[1]
        if (!is.na(test)){
          if (test > highest){
            highest <- test
          }
        }
        tempRes[j] <- test
        j <- j - 1
      }
      ert[[i]] <- tempRes
    }
    xSeq <- rev(xSeq)
    # NAs mit hohem Wert ersetzen
    for (i in 1:length(algorithms)){
      test <- ert[[i]]
      test[is.na(test)] <- 999999
      ert[[i]] <- test
    }
    
    ##########################
    # Plot 
    ##########################
    
    if (tm == "AT"){
      yLabel <- "ERT(AT)"
    }
    if (tm == "NT"){
      yLabel <- "ERT(NT)"
    }
    if (tm == "FE"){
      yLabel <- "ERT(FE)"
    }

    ertDf <- data.frame(relAbweichung = xSeq)
  
    i <- 1
    for (ee in ert){
      ertDf <- cbind(ertDf,ee)
      colnames(ertDf)[i+1] <- algorithms[i]
      i <- i + 1
    }
    write.csv(ertDf,paste("./ertTables", tm,"/",f,sep=""),row.names=F)
    cat(".")

  }
}
