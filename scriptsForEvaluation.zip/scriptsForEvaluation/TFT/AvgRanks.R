test <- read.csv("pValues3",stringsAsFactors = F)
rownames(test) <- test[,1]
test <- test[1:4,3:6]
test

resDf <- test
row.names(resDf) = 1:8
for (k in 1:8){
  test <- read.csv(paste("sixBuf",k,sep=""),stringsAsFactors = F)
  rownames(test) <- test[,1]
  test <- round(test[,2:6],1)
  test
  resDf[k,] <- round(apply(test,2,mean), digits=1)
}
resDf[9,] <- round(apply(resDf,2,mean),digits=1)

df10k <- read.csv("performance10000.csv")
test <- df10k[grepl("-100-m",df10k$instance) & df10k$instance %in% instanceNames,c("sppbo","dabc")]
test[,1] - test[,2]
