# laufe über jede Instanz
# packe für jedes Verfahren die Daten in einen Plot und schau das Ergebnis an

algorithms <- c("dabc",  "hvns", "sppbo",  "avi","api")
lineTypes <- rep("solid",5)#c("twodash", "twodash", "twodash", "twodash", "twodash")
timeMeasures <- c("./AT/", "./NT/", "./FE/")
instanceNames <- list.files("./instances")

parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
                    )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)

  return(parts)
}


johnsonBounds <- read.csv("johnsonBounds.csv", header=T, stringsAsFactors=F)

# Log-Skala
for (tm in timeMeasures){
  for (f in instanceNames){
    dfs <- list()
    instanceData <- parseInstanceName(f)
    counter <- 1
    for (algo in algorithms){
      fullName <- paste(f, algo,  sep="-")
      dfs[[counter]] <- read.csv(paste(tm, fullName, sep=""), header=T, stringsAsFactors = F)
      counter <- counter + 1
    }
    xMax <- 0
    if (instanceData$numberOfJobs == 10){
      next
    }
    if (instanceData$numberOfJobs == 50){
      xMax <- 300
    }
    if (instanceData$numberOfJobs == 75){
      xMax <- 600
    }
    if (instanceData$numberOfJobs == 100){
      xMax <- 900
    }
    johnsonBound <- johnsonBounds[johnsonBounds == f, 2]
    worstValues <- c()
    bestValues <- c()
    rightNTBorder <- Inf
    for (tempDf in dfs){
      if (rightNTBorder > tempDf[nrow(tempDf),1]){
        rightNTBorder <- tempDf[nrow(tempDf),1]
      }
      worstValues <- c(worstValues, tempDf[1,2])
      bestValues <- c(bestValues, tempDf[nrow(tempDf),2])
    }
    if (tm == timeMeasures[2] || tm == timeMeasures[3]){
      xMax <- rightNTBorder
    }
    worstValue <- max(worstValues, na.rm=T)
    bestValue <- min(bestValues, na.rm=T)
    
    if (tm == timeMeasures[1]){
      png(paste("./singleLogAT/", f,".png", sep=""))
      xLabel <- "absolute Zeit"
    }
    if (tm == timeMeasures[2]){
      png(paste("./singleLogNT/", f,".png", sep=""))
      xLabel <- "norm. Zeit"
    }
    if (tm == timeMeasures[3]){
      png(paste("./singleLogFE/", f,".png", sep=""))
      xLabel <- "Evaluation"
    }
    plot(c(10, xMax), c(bestValue,worstValue), type = "n", main = f,xlab=xLabel, ylab="Produktionsspanne", log="x")
    counter <- 1
    for (tempDf in dfs){
      lines(tempDf[,1], tempDf[,2], col=algoToColor(algorithms[counter]), lwd=2 ,lty = lineTypes[counter])
      counter <- counter + 1
    }
    legend("topright", 95, legend=toupper(algorithms),
           col=sapply(algorithms,function(x){algoToColor(x)}), lty=lineTypes, lwd=2, cex=0.8)
    dev.off()
    cat(".")
  }
}
algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  if (algo == "sppbo"){
    return("red")
  }
  if (algo == "api"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  return("black")
}

# normale-Skala
for (tm in timeMeasures){
  for (f in instanceNames){
    dfs <- list()
    instanceData <- parseInstanceName(f)
    counter <- 1
    for (algo in algorithms){
      fullName <- paste(f, algo,  sep="-")
      dfs[[counter]] <- read.csv(paste(tm, fullName, sep=""), header=T, stringsAsFactors = F)
      counter <- counter + 1
    }
    xMax <- 0
    if (instanceData$numberOfJobs == 10){
      next
    }
    if (instanceData$numberOfJobs == 50){
      xMax <- 300
    }
    if (instanceData$numberOfJobs == 75){
      xMax <- 600
    }
    if (instanceData$numberOfJobs == 100){
      xMax <- 900
    }
    johnsonBound <- johnsonBounds[johnsonBounds == f, 2]
    worstValues <- c()
    bestValues <- c()
    rightNTBorder <- Inf
    for (tempDf in dfs){
      if (rightNTBorder > tempDf[nrow(tempDf),1]){
        rightNTBorder <- tempDf[nrow(tempDf),1]
      }
      worstValues <- c(worstValues, tempDf[1,2])
      bestValues <- c(bestValues, tempDf[nrow(tempDf),2])
    }
    if (tm == timeMeasures[2] || tm == timeMeasures[3]){
      xMax <- rightNTBorder
    }
    worstValue <- max(worstValues, na.rm=T)
    bestValue <- min(bestValues, na.rm=T)
    
    if (tm == timeMeasures[1]){
      png(paste("./singleAT/", f,".png", sep=""))
      xLabel <- "absolute Zeit"
    }
    if (tm == timeMeasures[2]){
      png(paste("./singleNT/", f,".png", sep=""))
      xLabel <- "norm. Zeit"
    }
    if (tm == timeMeasures[3]){
      png(paste("./singleFE/", f,".png", sep=""))
      xLabel <- "Evaluation"
    }
    plot(c(0, xMax), c(bestValue,worstValue), type = "n", main = f,xlab=xLabel, ylab="Produktionsspanne")
    counter <- 1
    for (tempDf in dfs){
      lines(tempDf[,1], tempDf[,2], col=algoToColor(algorithms[counter]), lwd=2 ,lty = lineTypes[counter])
      counter <- counter + 1
    }
    legend("topright", 95, legend=toupper(algorithms),
           col=sapply(algorithms,function(x){algoToColor(x)}), lty=lineTypes, lwd=2, cex=0.8)
    dev.off()
    cat(".")
  }
}
