"
Plan:
  -durchschnittliche Performance nach 10k Evaluationen ermitteln
  -Performance am Ende

  
  -an sich muss man in verschiedenen Dimensionen aggregieren:
    -alles mit 50 Jobs
    -alles mit m2const,bufCount und so...

  -Schwelle: 1% in bester Lösung
  -Ideen: NEH initialisiert oft schlechter als Zufall
  -wer schnelle Initiallösung braucht? AVI
  -suche ein Beispiel, wo ein Zeitmaß gut, auf anderem Zeitmaß schlecht

  -
"
instanceNames <- list.files("./instances")

#4 Geser-Typen
totalM2ConstBufCount <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("total", instanceNames)]
interM2ConstBufCount <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("inter", instanceNames)]
totalM2ConstBufM1 <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("total", instanceNames)]
interM2ConstBufM1 <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("inter", instanceNames)]

interM2VarBufCount <- instanceNames[grepl("m2var-bufcount", instanceNames) & grepl("inter", instanceNames)]
totalM2VarBufM1 <- instanceNames[grepl("m2var-bufm1", instanceNames) & grepl("total", instanceNames)]

# n-Job-Probleme

n50Job <- instanceNames[startsWith(instanceNames, "f2inter-50") | startsWith(instanceNames, "f2total-50")]
n75Job <- instanceNames[startsWith(instanceNames, "f2inter-75") | startsWith(instanceNames, "f2total-75")]
n100Job <- instanceNames[startsWith(instanceNames, "f2inter-100") | startsWith(instanceNames, "f2total-100")]

# wachsender Buffer
bufSizeInstances <- list.files("./bufSizeInstances/")
n50JobC <- bufSizeInstances[grepl("-c-", bufSizeInstances)]
n50JobL <- n50Job[grepl("-l-", n50Job)]
n50JobKK <- n50Job[grepl("-kk-", n50Job)]
n50JobH <- n50Job[grepl("-h-", n50Job)]

# Für jede Art erfolgt Auswertung nach RPD, dann nach Weise
# wobei immer 