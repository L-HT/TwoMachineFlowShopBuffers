# Inf-Werte entfernen

for (tm in c("AT","FE","NT")){
  files <- list.files(paste("./",tm,sep=""))
  for (f in files){
    filePath <- paste("./",tm,"/",f,sep="")
    test <- read.csv(filePath)
    test <- test[test[,2] < .Machine$integer.max / 10,]
    write.csv(test,file = filePath,row.names = F)
  }
  cat(".")
}
