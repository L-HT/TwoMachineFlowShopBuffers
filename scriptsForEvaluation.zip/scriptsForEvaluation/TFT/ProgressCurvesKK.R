"
Plan:
  -Progress-Curve: auf jeder Instanz den Verlauf (Abweichung vom besten Wert) über jedes
    Zeitmaß zeigen
    -dazu die bereits bekannten Kurven nehmen und immer durch Best-Wert rechnen?
"

instanceNames <- list.files("./instances")
timeMeasures <- c("AT","NT","FE")
algorithms <- c("api","hvns","dabc","sppbo","avi")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")
for (tm in timeMeasures){
  for (f in instanceNames){
    optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
    #optimalTime <- johnsonTimes[johnsonTimes$instanceNames==f,2]
    instanceData <- parseInstanceName(f)
    dfs <- list()
    #instanceData <- parseInstanceName(f)
    counter <- 1
    for (algo in algorithms){
      fileName <- paste("./",tm,"/",f,"-",algo,sep="")
      data <- read.csv(fileName)
      data$makespan <- (data$makespan - optimalTime)/optimalTime
      dfs[[counter]] <- data
      counter <- counter + 1
    }
    
    
    xMax <- 0
    if (instanceData$numberOfJobs == 10){
      next
    }
    if (instanceData$numberOfJobs == 50){
      xMax <- 300
    }
    if (instanceData$numberOfJobs == 75){
      xMax <- 600
    }
    if (instanceData$numberOfJobs == 100){
      xMax <- 900
    }
    worstValues <- c()
    bestValues <- c()
    rightNTBorder <- Inf
    for (tempDf in dfs){
      if (rightNTBorder > tempDf[nrow(tempDf),1]){
        rightNTBorder <- tempDf[nrow(tempDf),1]
      }
      worstValues <- c(worstValues, tempDf[1,2])
      bestValues <- c(bestValues, tempDf[nrow(tempDf),2])
    }
    if (tm == timeMeasures[2] || tm == timeMeasures[3]){
      xMax <- rightNTBorder
    }
    worstValue <- max(worstValues, na.rm=T)
    
    
    if (tm == "AT"){
      png(paste("./relAT/", f,".png", sep=""))
      xLabel <- "absolute Zeit"
    }
    if (tm == "NT"){
      png(paste("./relNT/", f,".png", sep=""))
      xLabel <- "norm. Zeit"
    }
    if (tm == "FE"){
      png(paste("./relFE/", f,".png", sep=""))
      xLabel <- "Evaluation"
    }
    plot(c(0, xMax), c(0,worstValue*1.2), type = "n", main = f,xlab=xLabel, ylab="rel. Abweichung")
    counter <- 1
    for (tempDf in dfs){
      lines(tempDf[,1], tempDf[,2], col=algoToColor(algorithms[counter]), lwd=2 ,lty = "solid")
      counter <- counter + 1
    }
    legend("topright", 95, legend=toupper(algorithms),
           col=sapply(algorithms,function(x){algoToColor(x)}), lty="solid", lwd=2, cex=0.8)
    
    dev.off()
    cat(".")
  }
}
algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  if (algo == "sppbo"){
    return("red")
  }
  if (algo == "api"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  return("black")
}

# Log
tm <- "FE"
for (f in instanceNames){
  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
  #optimalTime <- johnsonTimes[johnsonTimes$instanceNames==f,2]
  instanceData <- parseInstanceName(f)
  dfs <- list()
  #instanceData <- parseInstanceName(f)
  counter <- 1
  for (algo in algorithms){
    fileName <- paste("./",tm,"/",f,"-",algo,sep="")
    data <- read.csv(fileName)
    data$makespan <- (data$makespan - optimalTime)/optimalTime
    dfs[[counter]] <- data
    counter <- counter + 1
  }
  
  
  xMax <- 0
  if (instanceData$numberOfJobs == 10){
    next
  }
  if (instanceData$numberOfJobs == 50){
    xMax <- 300
  }
  if (instanceData$numberOfJobs == 75){
    xMax <- 600
  }
  if (instanceData$numberOfJobs == 100){
    xMax <- 900
  }
  worstValues <- c()
  bestValues <- c()
  rightNTBorder <- Inf
  for (tempDf in dfs){
    if (rightNTBorder > tempDf[nrow(tempDf),1]){
      rightNTBorder <- tempDf[nrow(tempDf),1]
    }
    worstValues <- c(worstValues, tempDf[1,2])
    bestValues <- c(bestValues, tempDf[nrow(tempDf),2])
  }
  if (tm == timeMeasures[2] || tm == timeMeasures[3]){
    xMax <- rightNTBorder
  }
  worstValue <- max(worstValues, na.rm=T)
  

  if (tm == "FE"){
    png(paste("./logRelFE/", f,".png", sep=""))
    xLabel <- "Evaluation"
  }
  plot(c(10, xMax), c(0,worstValue*1.2), type = "n", main = f,xlab=xLabel, ylab="rel. Abweichung", log="x")
  counter <- 1
  for (tempDf in dfs){
    lines(tempDf[,1], tempDf[,2], col=algoToColor(algorithms[counter]), lwd=2 ,lty = "solid")
    counter <- counter + 1
  }
  legend("topright", 95, legend=toupper(algorithms),
         col=sapply(algorithms,function(x){algoToColor(x)}), lty="solid", lwd=2, cex=0.8)
  
  dev.off()
  cat(".")
}
