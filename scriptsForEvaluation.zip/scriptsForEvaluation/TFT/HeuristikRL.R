# bringt die Einbindung von RL überhaupt etwas?
# Aggregation über die 6 Typen
# für


algorithms <- c("sppbo", "sppbo-noh", "avi", "avi-norl", "api", "api-norl")

instanceNames <- list.files("./instancesClean")
instanceTypes <- c()
for (i in instanceNames){
  instanceTypes <- c(instanceTypes, getTypeOfInstance(i))
}
instanceTypeDf <- data.frame(name = instanceNames, type = instanceTypes)

for (f in instanceNames){
  for (algo in algorithms){
    fileName <- paste("./NT/",f,algo,sep="")
    test <- read.csv(paste("./NT/",f,algo,sep=""), header=T)
  }
}




################################
y <- matrix(c( 5,  4,  7, 10, 12,
               1,  3,  1,  0,  2,
               16, 12, 22, 22, 35,
               5,  4,  3,  5,  4,
               10,  9,  7, 13, 10,
               19, 18, 28, 37, 58,
               10,  7,  6,  8,  7),
            nrow = 7, byrow = TRUE,
            dimnames =
              list(Store = as.character(1:7),
                   Brand = LETTERS[1:5]))
PMCMR::posthoc.quade.test(y, dist="TDist", p.adj="none")

(Zeile) verkauft mehr als (Spalte)