# weitere Diagramme:

# für jede Instanz die beste ermittelte Produktionsspanne suchen


parseFlowShopName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                    "algorithm", "runNumber")
  if (length(parts) == 10){
    names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                      "algorithm", "runNumber", "fileSuffix")
  }
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  parts$runNumber <- as.integer(parts$runNumber)
  return(parts)
}


instanceNames <- list.files("./instances")
ALL_RESULTS <- list.files("./COMBINEDRESULTS/")

johnsonTimes <- read.csv("johnsonBounds.csv")
instanceColumn <- c()
bestValueColumn <- c()
winnerColumn <- c()
whereFoundColumn <- c()
johnsonAttained <- c()

for (f in instanceNames){
  fittingFiles <- ALL_RESULTS[startsWith(ALL_RESULTS,f)]
  if (length(fittingFiles) == 0){
    stop(paste("no ftting files for:",f))
  }
  bestMinValue <- Inf
  winnerName <- ""
  whereFound <- ""
  
  
  for (subF in fittingFiles){
    data <- read.csv(paste("./COMBINEDRESULTS/",subF, sep=""), header=F, stringsAsFactors=F)
    contenderName <- ""
    
    for (algo in algorithms){
      if (grepl(algo, subF)){
        contenderName <- algo
      }
      # if (algo == "sppbo"){
      #   for (h in heuristicsSPPBO){
      #     if (grepl(h,subF)){
      #       contenderName <- paste(contenderName, h, sep="-")
      #     }
      #   }
      # }
    }
    
    # if (grepl("avi", subF)){
    #   contenderName <- "avi"
    # }
    # if (grepl("hvns", subF)){
    #   contenderName <- "hvns"
    # }
    # if (grepl("dabc", subF)){
    #   contenderName <- "dabc"
    # }
    # if (grepl("sppbo", subF)){
    #   contenderName <- "sppbo"
    # }
    
    contenderValue <- data[nrow(data),4]
    
    # gleich guter Kandidat gefunden
    if (contenderValue == bestMinValue){
      if (grepl(contenderName, winnerName)){
        
      } else {
        winnerName <- paste(winnerName, contenderName, sep=",")
        whereFound <- ""
      }
    }

    # Verbesserung gefunden
    if (contenderValue < bestMinValue){
      bestMinValue <- contenderValue
      winnerName <- contenderName
      whereFound <- subF
    }
  }
  
  instanceColumn <- c(instanceColumn, f)
  bestValueColumn <- c(bestValueColumn, bestMinValue)
  winnerColumn <- c(winnerColumn, winnerName)
  whereFoundColumn <- c(whereFoundColumn, whereFound)
  
  # Abgleich mit Johnson-Bound
  if (bestMinValue == johnsonTimes[johnsonTimes$instanceNames == f,2]){
    johnsonAttained <- c(johnsonAttained, 1)
  } else {
    johnsonAttained <- c(johnsonAttained, 0)
  }
  cat(".")
}
resultDF <- data.frame(instance = instanceColumn, 
                       bestValue = bestValueColumn, 
                       winner = winnerColumn, 
                       whereFound = whereFoundColumn,
                       johnsonAttained = johnsonAttained)
write.csv(resultDF, "bestResults.csv", row.names=F, quote = T)

# wer hat wie oft mit die beste Lösung gefunden?
