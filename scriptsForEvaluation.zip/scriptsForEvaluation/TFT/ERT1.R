# Estimated Run-Time aufzeichnen

parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
  )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  
  return(parts)
}
algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  if (algo == "sppbo"){
    return("red")
  }
  if (algo == "api"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  return("black")
}

# AT

instanceNames <- list.files("./instances")
timeMeasures <- c("AT","NT","FE")
algorithms <- c("api","hvns","dabc","sppbo","avi")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")

for (f in instanceNames){
  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
  for (tm in timeMeasures){
    dfs <- list()
    i <- 1
    worstRel <- 0
    for (algo in algorithms){
      fileName <- paste("./",tm,"/",f,"-",algo,sep="")
      test <- read.csv(fileName,stringsAsFactors = F, header=T)
      test$makespan <- (test$makespan - optimalTime)/optimalTime
      if (test$makespan[1] > worstRel){
        worstRel <- test$makespan[1]
      }
      dfs[[i]] <- test
      i <- i +1
    }
    xSeq <- seq(from=worstRel, to=0, length.out=100)
    ert <- list()
    highest <- 0
    for (i in 1:length(algorithms)){
      tempRes <- rep(0,length(xSeq))
      j <- length(xSeq)
      for (x in xSeq){
        test <- dfs[[i]]
        test <- (test[test$makespan <= x,1])[1]
        if (!is.na(test)){
          if (test > highest){
            highest <- test
          }
        }
        tempRes[j] <- test
        j <- j - 1
      }
      ert[[i]] <- tempRes
    }
    xSeq <- rev(xSeq)
    # NAs mit hohem Wert ersetzen
    for (i in 1:length(algorithms)){
      test <- ert[[i]]
      test[is.na(test)] <- 99999
      ert[[i]] <- test
    }
    
    ##########################
    # Plot 
    ##########################
    
    if (tm == "AT"){
      png(paste("./ertAT/", f,".png", sep=""))
      yLabel <- "ERT(AT)"
    }
    if (tm == "NT"){
      png(paste("./ertNT/", f,".png", sep=""))
      yLabel <- "ERT(NT)"
    }
    if (tm == "FE"){
      png(paste("./ertFE/", f,".png", sep=""))
      yLabel <- "ERT(FE)"
    }
    plot(0,0, xlim = c(0,worstRel), ylim=c(0,highest),type="n", main=f,
         xaxs="i", 
         xlab="rel. Abweichung", ylab=yLabel)
    
    counter <- 1
    for (ee in ert){
      lines(xSeq, ee, col=algoToColor(algorithms[counter]), lwd=2 ,lty = "solid")
      counter <- counter + 1
    }
    legend("topright", 95, legend=toupper(algorithms),
           col=sapply(algorithms,function(x){algoToColor(x)}), lty="solid", lwd=2, cex=0.8)
   
    dev.off()
    cat(".")

  }
}
