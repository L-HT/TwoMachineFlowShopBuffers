# 770 Skripte
# für 7 Algos (DABC, HVNS, SPPBO, SPPBO-noH, AVI, API, AVInoRL, APInoRL)
# also 770*8=6160 Skripte


parseFlowShopName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                    "algorithm", "runNumber")
  if (length(parts) == 10){
    names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                      "algorithm", "runNumber", "fileSuffix")
  }
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  parts$runNumber <- as.integer(parts$runNumber)
  return(parts)
}

algorithms <- c("hvns", "sppbo",  "api")
#algorithms <- c("dabc")
instanceNames <- list.files("./instances")

###############################
# Function Evaluations
###############################

for (f in instanceNames){
  for (algo in algorithms){
    for (runNumber in 1:10){
      #fullName <- paste(f, algo, runNumber, sep="-")
      fullName <- paste(f, algo, runNumber,"noh", sep="-")
      tempDf <- read.csv(paste("./COMBINEDRESULTS/", fullName, sep=""), header=F, stringsAsFactors = F)
      tempDf <- tempDf[, -c(2,3)]
      
      if (runNumber == 1){
        bigDf <- tempDf
      }
      if (runNumber > 1){
        bigDf <- merge(bigDf, tempDf, by=c("V1"))
        colnames(bigDf) <- c("V1", paste("R",1:runNumber,sep=""))
      }
    }
    timeColumn <- bigDf[,1]
    restColumn <- bigDf[,-1]
    result <- data.frame(timeColumn, apply(restColumn,MARGIN = 1,FUN = mean))
    colnames(result) <- c("evaluation", "makespan")
    #write.csv(result,file = paste("./FE/", f, "-", algo, sep=""), row.names = F)
    write.csv(result,file = paste("./FE/", f, "-", algo, "-noh", sep=""), row.names = F)
    cat(".")
  }
}




