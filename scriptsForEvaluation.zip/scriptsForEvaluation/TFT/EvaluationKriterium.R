# relative Flächeninhalte der einzelnen Kurven berechnen

# Auswertung nach Kriterien

# -Durchschnittsrang PC NT
# -Durchschnittsrang PC FE
# -Durchschnittsrang ERT NT
# -Durchschnittsrang ERT FE
# -Durchschnittsrang ECDF NT
# -Durchschnittsrang ECDF FE
# -Endperformance
# -Frühperformance

instanceNames <- list.files("./instances")
pcNT <- read.csv("pcAreaNT", header=T, stringsAsFactors = F)
pcFE <- read.csv("pcAreaFE", header=T, stringsAsFactors = F)

ecdfNT <- read.csv("ecdfAreaNT", header=T, stringsAsFactors = F)
ecdfFE <- read.csv("ecdfAreaFE", header=T, stringsAsFactors = F)

ertNT <- read.csv("ertAreaNT", header=T, stringsAsFactors = F)
ertFE <- read.csv("ertAreaFE", header=T, stringsAsFactors = F)

endPerformance <- read.csv("endPerformance.csv")
startPerformance <- read.csv("performance10000.csv")

typeList <- list()

# Typ 1 (interM2ConstBufCount)
typeList[[1]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("inter", instanceNames)]

# Typ 2 (interM2ConstBufM1)
typeList[[2]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("inter", instanceNames)]

#Typ 3 (totalM2ConstBufCount)
typeList[[3]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("total", instanceNames)]

# Typ 4 (totalM2ConstBufM1)
typeList[[4]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("total", instanceNames)]

# Typ 7-9 (50/75/100-Job-Probleme)
typeList[[7]] <- instanceNames[grepl("-50-m", instanceNames)]
typeList[[8]] <- instanceNames[grepl("-75-m", instanceNames)]
typeList[[9]] <- instanceNames[grepl("-100-m", instanceNames)]


significantCounterStart <- 0
significantCounterEnd <- 0
####################################

bla <- rep(0,length(typeList))
resultDf <- data.frame(type=1:length(typeList))
i <- 1
for (algo in algorithms){
  resultDf <- cbind(resultDf, 1)
  colnames(resultDf)[i+1] <- algo
  i <- i + 1
}

for (iType in 1:9){
  instances <- typeList[[iType]]
  sub_pcNT <- pcNT[pcNT$instance %in% instances,
  sub_pcFE <- pcFE[pcFE$instance %in% instances,]
  
  sub_ecdfNT <- ecdfNT[ecdfNT$instance %in% instances,
  sub_ecdfFE <- ecdfFE[ecdfFE$instance %in% instances,]
  
  sub_ertNT <- ertNT[ertNT$instance %in% instances,]
  sub_ertFE <- ertFE[ertFE$instance %in% instances,
  
  sub_endP <- endPerformance[endPerformance$instance %in% instances,]
  sub_startP <- startPerformance[startPerformance$instance %in% instances,]
  
  ##########
  # neues Ranking (da Verfahren rausfallen)
  ##########
  
  for (f in instances){
    sub_pcNT[sub_pcNT$instance==f,2:6] <- rank(sub_pcNT[sub_pcNT$instance==f,-1])
    sub_pcFE[sub_pcFE$instance==f,2:6] <- rank(sub_pcFE[sub_pcFE$instance==f,-1])
    
    sub_ecdfNT[sub_ecdfNT$instance==f,2:6] <- rank(-sub_ecdfNT[sub_ecdfNT$instance==f,-1])
    sub_ecdfFE[sub_ecdfFE$instance==f,2:6] <- rank(-sub_ecdfFE[sub_ecdfFE$instance==f,-1])
    
    sub_ertNT[sub_ertNT$instance==f,2:6] <- rank(sub_ertNT[sub_ertNT$instance==f,-1])
    sub_ertFE[sub_ertFE$instance==f,2:6] <- rank(sub_ertFE[sub_ertFE$instance==f,-1])
  }
  
  criteria <- c("pcNT","pcFE","ecdfNT","ecdfFE","ertNT","ertFE")
  sixDf <- data.frame("criterion" = criteria)
  i <- 1
  for (algo in algorithms){
    sixDf <- cbind(sixDf, 1)
    colnames(sixDf)[i+1] <- algo
    i <- i + 1
  }
  sixDf[1,2:6] <- apply(sub_pcNT[,-1],2,mean)
  sixDf[2,2:6] <- apply(sub_pcFE[,-1],2,mean)
  sixDf[3,2:6] <- apply(sub_ecdfNT[,-1],2,mean)
  sixDf[4,2:6] <- apply(sub_ecdfFE[,-1],2,mean)
  sixDf[5,2:6] <- apply(sub_ertNT[,-1],2,mean)
  sixDf[6,2:6] <- apply(sub_ertFE[,-1],2,mean)
  
  write.csv(sixDf,file = paste("./six",iType,sep=""),row.names=F)
  
  points <- rank(apply(sub_pcNT[,-1],2,mean))
  points <- points + rank(apply(sub_pcFE[,-1],2,mean))
  points <- points + rank(apply(sub_ecdfNT[,-1],2,mean))
  points <- points + rank(apply(sub_ecdfFE[,-1],2,mean))
  points <- points + rank(apply(sub_ertNT[,-1],2,mean))
  points <- points + rank(apply(sub_ertFE[,-1],2,mean))
  
  pValueMatrix <- matrix("",nrow=5,ncol=5)
  colnames(pValueMatrix) <- algorithms
  rownames(pValueMatrix) <- algorithms
  
  for (i in 1:(length(algorithms)-1)){
    for (j in (i+1):length(algorithms)){
      
      
      
      algo1 <- algorithms[i]
      algo2 <- algorithms[j]
      
      perf1 <- sub_endP[,algo1]
      perf2 <- sub_endP[,algo2]
      
      algo1Better <- (median(perf1) < median(perf2))
      endTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="t")
      # if (algo1Better){
      #   endTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="less")
      # } else {
      #   endTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="greater")
      # }
      
      
      endSignificant <- ""
      if (!is.na(endTest$p.value)){
        if (endTest$p.value < 0.05){
          endSignificant <- "-"
        }
        if (endTest$p.value < 0.05/90){
          endSignificant <- "x"
          significantCounterEnd <- significantCounterEnd + 1
          print("signifikanter Unterschied End")
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            points[algo2] <- points[algo2] + 1
          } else {
            points[algo1] <- points[algo1] + 1
          }
        }
      }
      ##############################
      # Startperformance
      perf1 <- sub_startP[,algo1]
      perf2 <- sub_startP[,algo2]
      
      algo1Better <- (median(perf1) < median(perf2))
      startTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="t")
      
      # if (algo1Better){
      #   startTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="less")
      # } else {
      #   startTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="greater")
      # }
      
      startSignificant <- ""
      if (!is.na(startTest$p.value)){
        if (startTest$p.value < 0.05){
          startSignificant <- "-"
        }
        if (startTest$p.value < 0.05/90){
          startSignificant <- "x"
          significantCounterStart <- significantCounterStart + 1
          print("signifikanter Unterschied Start")
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            points[algo2] <- points[algo2] + 1
          } else {
            points[algo1] <- points[algo1] + 1
          }
        }
      }
      pValueMatrix[i,j] <- paste(endSignificant,startSignificant,sep="/")
    }
  }
  
  write.csv(pValueMatrix,paste("pValues",iType,sep=""),quote = T)
  resultDf[iType,2:6] <- points
  cat(".")
}
write.csv(resultDf, "bigTestResult.csv",row.names=F)

