# wie sehr weichen der Permutationen in AVI ab?

files <- list.files("./AVISolutions/")
files <- files[grepl("avi",files) & grepl("norl", files)]

bad <- c()
for (f in files){
  test <- readLines(paste("./AVISolutions/", f,sep=""))
  p1 <- test[1]
  p2 <- test[2]
  
  p1 <- sapply(strsplit(p1, split=",")[[1]], function(x){as.integer(substring(x,2))})
  p2 <- sapply(strsplit(p2, split=",")[[1]], function(x){as.integer(substring(x,2))})
  
  names(p1) <- NULL
  names(p2) <- NULL
  
  bad <- c(bad, sum(abs(p1-p2) > 0))
  names(bad)[length(bad)] <- f
}
