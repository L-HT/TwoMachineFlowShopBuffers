########################################

# Auswertung nach Kriterien

# -Median ERT NT
# -Median ERT FE
# -Median ECDF NT
# -Median ECDF FE
# -Endperformance
# -Frühperformance

pcNT <- read.csv("pcRanksNT", header=T)
pcFE <- read.csv("pcRanksFE", header=T)

ecdfNT <- read.csv("ecdfRanksNT", header=T)
ecdfFE <- read.csv("ecdfRanksFE", header=T)

ertNT <- read.csv("ertRanksNT", header=T)
ertFE <- read.csv("ertRanksFE", header=T)

endPerformance <- read.csv("endPerformance.csv")
startPerformance <- read.csv("performance10000.csv")

rank_pcNT <- sapply(pcNT[,2:ncol(pcNT)], mean)
rank_pcFE <- sapply(pcFE[,2:ncol(pcFE)], mean)
rank_ecdfNT <- sapply(ecdfNT[,2:ncol(ecdfNT)], mean)
rank_ecdfFE <- sapply(ecdfFE[,2:ncol(ecdfFE)], mean)
rank_ertNT <- sapply(ertNT[,2:ncol(ertNT)], mean)
rank_ertFE <- sapply(ertFE[,2:ncol(ertFE)], mean)

algorithms <- c("api","avi","sppbo")
for (algo in algorithms){
  if (algo == "api"){
    algo2 <- "api.norl"
  }
  if (algo == "avi"){
    algo2 <- "avi.norl"
  }
  if (algo == "sppbo"){
    algo2 <- "sppbo.noh"
  }
  points <- rank(rank_ecdfNT[c(algo,algo2)]) - 1
  points <- points + rank(rank_ecdfFE[c(algo,algo2)]) - 1
  points <- points + rank(rank_ertNT[c(algo,algo2)]) - 1
  points <- points + rank(rank_ertFE[c(algo,algo2)]) - 1
  points <- points + rank(rank_pcNT[c(algo,algo2)]) - 1
  points <- points + rank(rank_pcFE[c(algo,algo2)]) - 1
  
  values <- endPerformance[,algo] 
  noHValues <- endPerformance[,algo2]
  if (median(values) > median(noHValues)){
    valuesLarger <- TRUE
  } else {
    valuesLarger <- FALSE
  }
  endTest <- wilcox.test(values, noHValues, paired=TRUE, exact=TRUE)
  
  if (endTest$p.value < 0.05){
    if (valuesLarger){
      points <- points + c(1,0)
    } else {
      points <- points + c(0,1)
    }
  }
  # Teste Startperformance
  values <- startPerformance[,algo]  
  noHValues <- startPerformance[,algo2]
  
  if (median(values) > median(noHValues)){
    valuesLarger <- TRUE
  } else {
    valuesLarger <- FALSE
  }
  startTest <- wilcox.test(values, noHValues, paired=TRUE, exact=TRUE)
  if (startTest$p.value < 0.05){
    if (valuesLarger){
      points <- points + c(1,0)
    } else {
      points <- points + c(0,1)
    }
  }
  print(points)
}

################################
