# wie sieht es aus mit der Skalierbarkeit der Zeitmaße?
# NT: springt ziemlich hin und her