# SPPBO-JJ Suffix anhängen

ALL_RESULTS <- list.files("outputJJ")

setwd("./outputJJ/")
for (f in ALL_RESULTS){
  
  partialStrings <- strsplit(f, "-")[[1]]
  if (length(partialStrings) >= 10){
    partialStrings[8] <- paste(partialStrings[8],"jj",sep="")
    newName <- paste(partialStrings[c(1:8,10,9)], collapse="-")
    file.rename(f, newName)
  }
}

setwd("../")

