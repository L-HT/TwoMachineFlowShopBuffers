# Fläche von PC berechnen und Ranking bilden

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")


for (tm in timeMeasures){
  pcFiles <- list.files(paste("./pc",tm,sep=""))
  
  # Data Frame initialisieren
  resultDf <- data.frame(instance = pcFiles)
  i <- 1
  for (algo in algorithms){
    resultDf <- cbind(resultDf, 1)
    colnames(resultDf)[i+1] <- algo
    i <- i + 1
  }
  
  
  for (f in pcFiles){
    test <- read.csv(paste("./pc",tm,"/",f,sep=""))
    naCount <- apply(test,2,function(x){sum(is.na(x))})
    naCount <- max(naCount[names(naCount) != "avi"]) + 1
    
    test <- test[naCount:nrow(test),]
    
    sums <- apply(test[,2:ncol(test)],MARGIN = 2,FUN=function(x){sum(x,na.rm = T)})
    ranks <- sums#rank(sums)
    names(ranks) <- algorithms

    for (algo in algorithms){
      resultDf[resultDf$instance == f, algo] <- ranks[algo] 
     
    }
    
  }
  write.csv(resultDf, paste("pcArea",tm,sep=""),row.names=F)
  #write.csv(resultDf, paste("pcRanks",tm,sep=""),row.names=F)
  cat(".")
}
