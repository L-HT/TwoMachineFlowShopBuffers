# delete HVNS

ALL_RESULTS <- list.files("./HVNSonly/output/")
setwd("./HVNSonly/output/")
for (f in ALL_RESULTS){
  
  partialStrings <- strsplit(f, "-")[[1]]
  if (as.numeric(partialStrings[9]) > 3){
    file.remove(f)
  }

}

setwd("../../")


# delete AVI

ALL_RESULTS <- list.files("./AVIResults/")
setwd("./AVIResults/")
for (f in ALL_RESULTS){
  
  partialStrings <- strsplit(f, "-")[[1]]
  if (as.numeric(partialStrings[9]) > 3){
    file.remove(f)
  }
  
}
setwd("../")