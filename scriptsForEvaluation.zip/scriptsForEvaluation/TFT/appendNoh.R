hNames <- c("constructgp","jh","johnsongp","nehgp")

sppboIndices <- sapply(ALL_RESULTS,function(x){
  !any(endsWith(x,hNames))
})

test <- ALL_RESULTS[sppboIndices]

setwd("./COMBINEDRESULTS/")
oldNames <- test
file.rename(test[11:length(test)],paste(test[11:length(test)],"-noh",sep=""))
setwd("../")
