
algoToColor <- function(algo){
  if (algo == "sppbo-noh"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  if (algo == "sppbo-amd"){
    return("red")
  }
  if (algo == "sppbo-mit"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  if (algo == "sppbo-mmd"){
    return("blue")
  }
  if (algo == "sppbo-bum"){
    return("grey50")
  }
  return("black")
}


# getTypeOfInstance <- function(f){
#   instanceData <- parseInstanceName(f)
#   
#   
# 
#   
#   if (instanceData$bufferType == "intermediateBuffer" && 
#       instanceData$bufType == "bufcount"){
#     return(1)
#   }
#   
#   if (instanceData$bufferType == "totalBuffer" && 
#       instanceData$bufType == "bufcount"){
#     return(2)
#   }
#   
#   if (instanceData$bufferType == "totalBuffer" && 
#       instanceData$bufType == "bufcount"){
#     return(3)
#   }
#   
#   if (instanceData$bufferType == "totalBuffer" && 
#       instanceData$bufType == "bufm1"){
#     return(4)
#   }
#   
#   message(paste("Typ nicht erkannt:", f))
#   return(-999)
# }
# parseInstanceName <- function(fileName){
#   parts <- as.list(strsplit(fileName, "-")[[1]])
#   names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
#   )
#   
#   if (parts$bufferType == "f2inter"){
#     parts$bufferType <- "intermediateBuffer"
#   } else if (parts$bufferType == "f2total"){
#     parts$bufferType <- "totalBuffer"
#   }
#   parts$numberOfJobs <- as.integer(parts$numberOfJobs)
#   parts$maxBufferSize <- as.integer(parts$maxBufferSize)
#   parts$instanceNumber <- as.integer(parts$instanceNumber)
#   
#   return(parts)
# }
