"
Plan:
  -Progress-Curve: auf jeder Instanz den Verlauf (Abweichung vom besten Wert) über jedes
    Zeitmaß zeigen
    -dazu die bereits bekannten Kurven nehmen und immer durch Best-Wert rechnen?
"

instanceNames <- list.files("./instances")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")
for (tm in timeMeasures){
  for (f in instanceNames){
    optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
    #optimalTime <- johnsonTimes[johnsonTimes$instanceNames==f,2]
    instanceData <- parseInstanceName(f)
    dfs <- list()
    #instanceData <- parseInstanceName(f)
    counter <- 1
    leftLimit <- 0
    rightLimit <- Inf
    for (algo in algorithms){
      fileName <- paste("./",tm,"/",f,"-",algo,sep="")
      data <- read.csv(fileName)
      data$makespan <- (data$makespan - optimalTime)/optimalTime
      
      if (leftLimit < data[1,1]){
        leftLimit <- data[1,1]
      }
      if (rightLimit > data[nrow(data),1]){
        rightLimit <- data[nrow(data),1]
      }
      dfs[[counter]] <- data
      counter <- counter + 1
      
    }
    
    xSeq <- seq(from=0,to=rightLimit,length.out = 500)
    
    pcs <- list()
    for (i in 1:length(algorithms)){
      tempRes <- rep(0,length(xSeq))
      for (j in 1:length(xSeq)){
        test <- dfs[[i]]
        if (any(test[,1] <= xSeq[j])){
          test <- test[test[,1] <= xSeq[j],]
          test <- test[nrow(test),2]
          tempRes[j] <- test
        } else {
          # NA: zu diesem Zeitpunkt hat der Algo noch keine Werte (Inf)
          tempRes[j] <- NA
        }
        
      }
      pcs[[i]] <- tempRes
    }
    
    
    if (tm == "FE"){
      pcDf <- data.frame(FE = xSeq)
    }
    if (tm == "NT"){
      pcDf <- data.frame(NT = xSeq)
    }
    
    i <- 1
    for (pc in pcs){
      pcDf <- cbind(pcDf,pc)
      colnames(pcDf)[i+1] <- algorithms[i]
      i <- i + 1
    }
    write.csv(pcDf,paste("./pc", tm,"/",f,sep=""),row.names=F)
    
    cat(".")
  }
}
