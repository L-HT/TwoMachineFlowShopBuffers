"
Wie sieht die Pipeline aus?
"

# zu vergleichende Algorithmen
algorithms <- c("acols-lowEva", "hvns", "dabc", "ils-cut")

# Kurznamen (für Plots)
algorithms2 <- c("acols", "hvns", "dabc", "ils")

# algorithms2 <- c("noh", "jh", "johnson", "neh", "construct")

# heuristicsSPPBO <- c("noh", "jh",  "johnsongp", "nehgp", "constructgp")
timeMeasures <- c("FE", "NT")

numberOfTypes <- 10
numberOfRuns <- 10
instanceNames <- list.files("./instances") 
typeList <- list()

# Typ 1 (interM2ConstBufCount)
typeList[[1]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("inter", instanceNames)]

# Typ 2 (interM2ConstBufM1)
typeList[[2]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("inter", instanceNames)]

#Typ 3 (totalM2ConstBufCount)
typeList[[3]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("total", instanceNames)]

# Typ 4 (totalM2ConstBufM1)
typeList[[4]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("total", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[5]] <- instanceNames[grepl("small", instanceNames)]
typeList[[6]] <- instanceNames[grepl("mid", instanceNames)]
typeList[[7]] <- instanceNames[grepl("big", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[8]] <- instanceNames[grepl("bufcount", instanceNames)]
typeList[[9]] <- instanceNames[grepl("bufm1", instanceNames)]


#-NEH-Times und Johnson-Bounds berechnen für jede Instanz
source("calculateNehTimes.R")
source("calculateJohnsonBounds.R")

# Umbenennung
# source("renameCombinedResults.R")

# DABC vorverarbeiten
#source("PreProcessAVI.R")

# -bestTimes for EachInstance (zusammen, ob Johnson erreicht wurde)
source("bestTimesForEachInstance.R")

#throwaway entfernen
if (file.exists("./COMBINEDRESULTS/throwaway")){
  file.remove("./COMBINEDRESULTS/throwaway")
} 

# Aus COMBINEDRESULTS werden die einzelnen Tabellen für FE, NT erstellt
# source("eval3MeasuresSPPBO.R")
# 
# if (any(algorithms != "sppbo")){
source("eval3Measures.R")
# }

# Performance an festen Zeitpunkten (### hier hängt es noch)
source("EndPerformance10000.R")

# Inf-Werte entfernen (weil an den Stellen die Algos nicht
# vergleichbar sind)
source("removeInf.R")

# Daten für  PC und ERT bzgl FE und NT berechnen
source("pc_df.R")
source("ERTDf.R")

# aus den COMBINEDRESULTS außerdem die ECDFs für FE und NT berechnet
# (d.h. die Tabellen dafür)
source("ECDF_Df.R")

# -anschließend für jedes Diagramm den Flächeninhalt berechnen
source("ECDF_area.R")
source("ERT_area.R")
source("pc_area.R")


algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  
  if (algo == "sppbo-mit" || algo == "sppbojj-mit"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  if (algo == "sppbo-mmd" || algo == "sppbojj-mmd"){
    return("blue")
  }
  if (algo == "sppbo-bum" || algo == "sppbojj-bum"){
    return("grey50")
  }
  if (algo == "ils" || algo == "ils-cut" || algo == "ils-neh"){
    return("aquamarine")
  }
  if (algo == "acols" || algo=="acols-lowEva"){
    return("red")
  }
  
  return("black")
}

algoToLineType <- function(algo){
  if (grepl("jj",algo)){
    #return("dashed")
  }
  if (grepl("lowEva",algo) ||  grepl("neh", algo)){
    #return("dashed")
  }
  return("solid")
}



# Plots für all diese Dinge 
source("PlotsForEachType.R")

# dann die relativen Flächeninhalte bezüglich der einzelnen Typen ermitteln
source("relArea.R")

# -statistische Tests durchführen, ob sich die Performance der einzelnen Typen
# unterscheidet
source("statisticalTest.R")

# Durchschnitte nehmen je nach Instanztyp

source("writeNormalizedRank.R")

source("aggMeasures.R")
