# ECDF zeichnen

parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
  )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  
  return(parts)
}
algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  if (algo == "sppbo"){
    return("red")
  }
  if (algo == "api"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  return("black")
}

instanceNames <- list.files("./instances")
timeMeasures <- c("AT","NT","FE")
algorithms <- c("api","hvns","dabc","sppbo","avi")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")
nehTimes <- read.csv("nehTimes.csv")

startTime <- Sys.time()
for (f in instanceNames){
  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
  goalValue <- ceiling(optimalTime * 1.01)
  instanceData <- parseInstanceName(f)
  
  for (tm in timeMeasures){
    dfs <- list()
    ecdf <- list()
    ecdfCounter <- 1
    worstRel <- 0
    rightLimit <- 0
    
    for (algo in algorithms){
      algoDfs <- list()
      currentEcdf <- c()
      for (run in 1:10){
        fileName <- paste("./COMBINEDRESULTS/",f,"-",algo,"-",run,sep="")
        test <- read.csv(fileName,stringsAsFactors = F, header=F)
        
        if (tm == "AT"){
          test <- test[,c(2,4)]
        }
        if (tm == "NT"){
          test <- test[,c(2,4)]
          test[,1] <- test[,1] / nehTimes[nehTimes$instanceNames == f,2]
        }
        if (tm == "FE"){
          test <- test[,c(1,4)]
        }
        maxTime <- test[nrow(test),1]
        if (maxTime > rightLimit){
          rightLimit <- maxTime
        }
        algoDfs[[run]] <- test
      }
      
      xSeq <- ceiling(seq(0,rightLimit,length.out = 150))
      currentEcdf <- rep(0, 150)
      i <- 1
      for (x in xSeq){
        successes <- 0
        for (run in 1:10){
          test <- algoDfs[[run]]
          valuesReached <- test[test[,1] <= x,2]
          if (length(valuesReached) > 0){
            if (valuesReached[length(valuesReached)] <= goalValue){
              successes <- successes + 1
            }
          }
        }
        currentEcdf[i] <- successes/10
        i <- i + 1
      }
      tempRes <- data.frame(xSeq, currentEcdf)
      colnames(tempRes) <- c("x","y")
      ecdf[[ecdfCounter]] <- tempRes
      ecdfCounter <- ecdfCounter + 1
    }
    
    # Tabellen auf gleiche Länge bringen
    for (i in 1:length(algorithms)){
      test <- ecdf[[i]]
      column1 <- test[,1]
      column2 <- test[,2]
      lastValue <- test[nrow(test),"y"]
      column1 <- c(column1, rightLimit)
      column2 <- c(column2, lastValue)
      ecdf[[i]] <- data.frame(x = column1, y = column2)
    }
    ##########################
    # Plot 
    ##########################
    
    if (tm == "AT"){
      png(paste("./ecdfAT/", f,".png", sep=""))
      xLabel <- "absolute Zeit"
    }
    if (tm == "NT"){
      png(paste("./ecdfNT/", f,".png", sep=""))
      xLabel <- "norm. Zeit"
    }
    if (tm == "FE"){
      png(paste("./ecdfFE/", f,".png", sep=""))
      xLabel <- "Evaluation"
    }
    plot(0,0, xlim = c(0,rightLimit), ylim=c(0,1),type="n", main=f, 
         xlab=xLabel, ylab="1%-ECDF")
    
    counter <- 1
    lineTypes <- c("twodash", "solid", "dashed", "", "twodash")
    
    for (ee in ecdf){
      
      lines(ee$x, ee$y, col=algoToColor(algorithms[counter]), lwd=2 ,lty = "solid")
      counter <- counter + 1
    }
    legend("topleft", 95, legend=toupper(algorithms),
           col=sapply(algorithms,function(x){algoToColor(x)}), lty="solid", lwd=2, cex=0.8)
    dev.off()
    cat(".")
    
  }
}
print(Sys.time()-startTime)
