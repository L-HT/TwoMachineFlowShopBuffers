"
Wie sieht die Pipeline aus?
"

# zu vergleichende Algorithmen
algorithms <- c("acols-lowEva", "hvns", "dabc", "ils-cut")

# Kurznamen (für Plots)
algorithms2 <- c("acols", "hvns", "dabc", "ils")

#
timeMeasures <- c("FE", "NT")

numberOfTypes <- 10
numberOfRuns <- 10
instanceNames <- list.files("./instances") 
typeList <- list()

# Typ 1 (interM2ConstBufCount)
typeList[[1]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("inter", instanceNames)]

# Typ 2 (interM2ConstBufM1)
typeList[[2]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("inter", instanceNames)]

#Typ 3 (totalM2ConstBufCount)
typeList[[3]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("total", instanceNames)]

# Typ 4 (totalM2ConstBufM1)
typeList[[4]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("total", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[5]] <- instanceNames[grepl("small", instanceNames)]
typeList[[6]] <- instanceNames[grepl("mid", instanceNames)]
typeList[[7]] <- instanceNames[grepl("big", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[8]] <- instanceNames[grepl("bufcount", instanceNames)]
typeList[[9]] <- instanceNames[grepl("bufm1", instanceNames)]

###################################



parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber"
  )
  
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  
  return(parts)
}


parseFlowShopName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                    "algorithm", "runNumber")
  if (length(parts) == 10){
    names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                      "algorithm", "runNumber", "fileSuffix")
  }
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  parts$runNumber <- as.integer(parts$runNumber)
  return(parts)
}

#######################################
source("eval3Measures.R")


# Daten für  PC und ERT bzgl FE und NT berechnen
source("pc_df.R")
source("ERTDf.R")

# aus den COMBINEDRESULTS außerdem die ECDFs für FE und NT berechnet
# (d.h. die Tabellen dafür)
source("ECDF_Df.R")

# -anschließend für jedes Diagramm den Flächeninhalt berechnen
source("ECDF_area.R")
source("ERT_area.R")
source("pc_area.R")


algoToColor <- function(algo){
  if (algo == "dabc"){
    return("green")
  }
  if (algo == "hvns"){
    return("violet")
  }
  
  if (algo == "sppbo-mit" || algo == "sppbojj-mit"){
    return("orange")
  }
  if (algo == "avi"){
    return("brown")
  }
  if (algo == "sppbo-mmd" || algo == "sppbojj-mmd"){
    return("blue")
  }
  if (algo == "sppbo-bum" || algo == "sppbojj-bum"){
    return("grey50")
  }
  if (algo == "ils" || algo == "ils-cut" || algo == "ils-neh"){
    return("aquamarine")
  }
  if (algo == "acols" || algo=="acols-lowEva"){
    return("red")
  }
  
  return("black")
}

algoToLineType <- function(algo){
  if (grepl("jj",algo)){
    #return("dashed")
  }
  if (grepl("lowEva",algo) ||  grepl("neh", algo)){
    #return("dashed")
  }
  return("solid")
}



# Plots für all diese Dinge 
source("PlotsForEachType.R")

# dann die relativen Flächeninhalte bezüglich der einzelnen Typen ermitteln
source("relArea.R")

# -statistische Tests durchführen, ob sich die Performance der einzelnen Typen
# unterscheidet
source("statisticalTest.R")


