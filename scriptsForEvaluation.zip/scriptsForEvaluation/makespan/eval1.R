"
Wie sieht die Pipeline aus?
"

# zu vergleichende Algorithmen
algorithms <- c("hvns", "dabc", "acols-lowEva", "ils-neh", "hvns-tuned", "dabc-tuned")

# Kurznamen (für Plots)
#algorithms2 <- c("acols-lowEva", "hvns", "dabc",  "ils-cut", "ils-neh")

algorithms2 <- c("hvns", "dabc", "aco", "2bf-ils", "hvns-t", "dabc-t")

# heuristicsSPPBO <- c("noh", "jh",  "johnsongp", "nehgp", "constructgp")
timeMeasures <- c("FE", "NT")

numberOfTypes <- 1
numberOfRuns <- 10
instanceNames <- list.files("./instances") 
typeList <- list()

# Typ 1 
typeList[[1]] <- instanceNames

#-NEH-Times und Johnson-Bounds berechnen für jede Instanz
source("calculateNehTimes.R")
source("calculateJohnsonBounds.R")

#source("PreProcessAVI.R")

# -bestTimes for EachInstance (zusammen, ob Johnson erreicht wurde)
source("bestTimesForEachInstance.R")

#throwaway entfernen
if (file.exists("./COMBINEDRESULTS/throwaway")){
  file.remove("./COMBINEDRESULTS/throwaway")
} 

# Aus COMBINEDRESULTS werden die einzelnen Tabellen für FE, NT erstellt
# source("eval3MeasuresSPPBO.R")
# 
# if (any(algorithms != "sppbo")){
  source("eval3Measures.R")
# }

# Performance an festen Zeitpunkten (### hier hängt es noch)
source("EndPerformance10000.R")

# Inf-Werte entfernen (weil an den Stellen die Algos nicht
# vergleichbar sind)
source("removeInf.R")

# Daten für  PC und ERT bzgl FE und NT berechnen
source("pc_df.R")
source("ERTDf.R")

# aus den COMBINEDRESULTS außerdem die ECDFs für FE und NT berechnet
# (d.h. die Tabellen dafür)
source("ECDF_Df.R")

# -anschließend für jedes Diagramm den Flächeninhalt berechnen
source("ECDF_area.R")
source("ERT_area.R")
source("pc_area.R")

algoToColor <- function(algo){
  if (algo == "dabc" || algo == "dabc-tuned"){
    return("#d7191c")
  }
  if (algo == "hvns" || algo == "hvns-tuned"){
    return("#fdae61")
  }
  if (algo == "acols" || algo=="acols-lowEva"){
    return("#abdda4")
  }
  if (algo == "ils" || algo == "ils-cut" || algo == "ils-neh"){
    return("#2b83ba")
  }
  return("black")
}

algoToLineType <- function(algo){
  if (grepl("jj",algo)){
    return("dotdash")
  }
  if (grepl("tuned", algo)){
    return("dashed")
  }
  return("solid")
}

# Plots für all diese Dinge 
source("PlotsForEachType.R")

# dann die relativen Flächeninhalte bezüglich der einzelnen Typen ermitteln
source("relArea.R")

# -statistische Tests durchführen, ob sich die Performance der einzelnen Typen
# unterscheidet
source("statisticalTest.R")

# Durchschnitte nehmen je nach Instanztyp

source("writeNormalizedRank.R")

source("aggMeasures.R")
