# Fläche von ECDF berechnen und Ranking bilden

instanceNames <- list.files("./instances")

kkInstances <- instanceNames[grepl("kk", instanceNames)]
johnsonTimes <- read.csv("johnsonBounds.csv")
bestFoundTimes <- read.csv("bestResults.csv")


for (tm in timeMeasures){
  ecdfFiles <- list.files(paste("./ecdfTables",tm,sep=""))
  
  # Data Frame initialisieren
  resultDf <- data.frame(instance = ecdfFiles)
  i <- 1
  for (algo in algorithms){
    resultDf <- cbind(resultDf, 1)
    colnames(resultDf)[i+1] <- algo
    i <- i + 1
  }
  
  
  for (f in ecdfFiles){
    test <- read.csv(paste("./ecdfTables",tm,"/",f,sep=""))
    sums <- apply(test[,2:ncol(test)],MARGIN = 2,FUN=sum)
    
    names(sums) <- algorithms
    
    for (algo in algorithms){
      resultDf[resultDf$instance == f, algo] <- sums[algo] 
     
    }
    
  }
  write.csv(resultDf, paste("ecdfArea",tm,sep=""),row.names=F)
  #write.csv(resultDf, paste("ecdfRanks",tm,sep=""),row.names=F)
}
