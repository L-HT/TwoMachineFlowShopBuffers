# -statistische Tests durchführen, ob sich die Performance der 
# einzelnen Typen unterscheidet

endPerformanceDf <- read.csv("endPerformance.csv", stringsAsFactors=F, check.names = F)
performance10000Df <- read.csv("performance100000.csv", stringsAsFactors=F, check.names = F)


numberOfTests <- ( length(algorithms) * (length(algorithms)-1)/2 ) * numberOfTypes
instanceTypes <- 0:length(typeList)

chooseBetterAlgorithm <- function(perf1, perf2){
  if (median(perf1)==median(perf2)){
    # print("Test by means")
    if (mean(perf1) != mean(perf2)){
      result <- (mean(perf1) < mean(perf2))
    } else {
      if (!identical(perf1, perf2)){
        myText <- paste("Typ ", iType, ": ", algo1, " und ", algo2, " haben gleichen Mittelwert und Median",sep="")
        warning(myText)
      }
      result <- NA
    }
  } else {
    result <- (median(perf1) < median(perf2))
  }
  return(result)
}

reverseRelation <- function(s){
  if (s == ""){return(s)}
  if (s == ">"){return("<")}
  if (s == ">>"){return("<<")}
  if (s == "<"){return(">")}
  if (s == "<<"){return(">>")}
  if (s == "\\leerUp"){return(s)}
  if (s == "$\\blacktriangle$"){return("$\\blacktriangleleft$")}
  if (s == "$\\blacktriangleleft$"){return("$\\blacktriangle$")}
}

#### Endperformance
for (iType in instanceTypes){
  if (iType == 0){
    sub_startP <- performance10000Df[,]
    sub_endP <- endPerformanceDf[,]
  } else {
    sub_startP <- performance10000Df[performance10000Df$instance %in% typeList[[iType]],]
    sub_endP <- endPerformanceDf[endPerformanceDf$instance %in% typeList[[iType]],]
  }
  pValueMatrix <- matrix("",nrow=length(algorithms),ncol=length(algorithms))
  colnames(pValueMatrix) <- algorithms
  rownames(pValueMatrix) <- algorithms
  
  for (i in 1:(length(algorithms)-1)){
    for (j in (i+1):length(algorithms)){

      algo1 <- algorithms[i]
      algo2 <- algorithms[j]
      
      perf1 <- sub_endP[,algo1]
      perf2 <- sub_endP[,algo2]
      
      algo1Better <- chooseBetterAlgorithm(perf1, perf2)
      if (is.na(algo1Better)){
        next
      }
      
      #Vorzeichen-Test (mit Entfernung von Bindungen)
      endTest <- BSDA::SIGN.test(perf1, perf2)
      
      #Symmetrie-Test basierend auf der Vorzeichenstatistik von Wilcoxon
      #endTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T)

      endSignificant <- ""
      if (!is.na(endTest$p.value)){
        if (endTest$p.value < 0.05){
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            endSignificant <- "<"
          } else {
            endSignificant <- ">"
          }
        }
        if (endTest$p.value < 0.05/numberOfTests){
          #endSignificant <- "x"
          #significantCounterEnd <- significantCounterEnd + 1
          # print("signifikanter Unterschied End")
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            endSignificant <- "<<"
          } else {
            endSignificant <- ">>"
          }
        }
      }
      ##############################
      # Startperformance
      perf1 <- sub_startP[,algo1]
      perf2 <- sub_startP[,algo2]
      
      algo1Better <- chooseBetterAlgorithm(perf1, perf2)
      if (is.na(algo1Better)){
        next
      }
      #Vorzeichen-Test (mit Entfernung von Bindungen)
      startTest <- BSDA::SIGN.test(perf1, perf2)
      
      #Symmetrie-Test basierend auf der Vorzeichenstatistik von Wilcoxon
      #startTest <- wilcox.test(perf1, perf2, paired=TRUE, exact=T, alternative="t")
      
      startSignificant <- ""
      if (!is.na(startTest$p.value)){
        if (startTest$p.value < 0.05){
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            startSignificant <- "<"
          } else {
            startSignificant <- ">"
          }
        }
        if (startTest$p.value < 0.05/numberOfTests){
          #startSignificant <- "x"
          #significantCounterStart <- significantCounterStart + 1
          # print("signifikanter Unterschied Start")
          if (algo1Better){ # der schlechtere kriegt einen Punkt
            startSignificant <- "<<"
          } else {
            startSignificant <- ">>"
          }
        }
      }
      # zu lesen als (Zeile) (Relationszeichen) (Spalte)
      pValueMatrix[i,j] <- paste(startSignificant,endSignificant,sep="/")
      pValueMatrix[j,i] <- paste(reverseRelation(startSignificant),reverseRelation(endSignificant),sep="/")
    }
  }
  
  write.table(pValueMatrix,paste("pValues",iType,".csv",sep=""),quote = F,
            sep=" & ", eol = " \\\\ \n")

}
