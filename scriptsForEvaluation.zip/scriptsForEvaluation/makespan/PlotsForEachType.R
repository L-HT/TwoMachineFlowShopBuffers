# Plots machen

bestFoundTimes <- read.csv("bestResults.csv")
####################################
for (iType in 1:numberOfTypes){
  for (f in typeList[[iType]]){
    # Plotte ERT, ECDF, PC
    cat(".")
    for (tm in timeMeasures){
      
      ############
      # ERT
      ############
      
      test <- read.csv(paste("./ertTables",tm,"/",f,sep=""),header=T, check.names = F)
      columnsToKeep <- c(T,colnames(test[,2:ncol(test)]) %in% algorithms)
      test <- test[,columnsToKeep]
      
      worstRel <- test$relAbweichung[nrow(test)]
      # den höchsten Ordinatenwert ermitteln (ohne Inf)
      highest <- max( 
        apply(
          test[,2:(1+length(algorithms))],
          MARGIN = 2,FUN = 
            function(x){
              temp <- unique(sort(x, decreasing = T))
              if (length(temp)==1){ #wenn sofort 0 erreicht, nimm 0
                return(temp)
              } else {
                return(temp[2]) #sonst den Wert nach inf
              }
            }
        )
      )
      fileName <- paste("./plots/ert",tm,"_",f,".png",sep="")
      png(fileName)
      if (tm == "NT"){
        yLabel <- "ERT(NT)"
      }
      if (tm == "FE"){
        yLabel <- "ERT(FE)"
      }
      plot(0,0, xlim = c(0,worstRel), ylim=c(0,highest),type="n", main=f,
           xaxs="i", 
           xlab="RPD (Makespan)", ylab=yLabel)
      
      counter <- 1
      for (i in 2:(1+length(algorithms))){
        lines(test$relAbweichung, test[,i], col=algoToColor(algorithms[counter]), lwd=2 ,lty = algoToLineType(algorithms[counter]))
        counter <- counter + 1
      }
      legend("topright", 95, legend=toupper(algorithms2),
             col=sapply(algorithms,function(x){algoToColor(x)}), 
             lty=sapply(algorithms,function(x){algoToLineType(x)}), 
             lwd=2, cex=0.8)
      dev.off()
      
      ###############
      # ECDF
      ###############
      
      test <- read.csv(paste("./ecdfTables",tm,"/",f,sep=""),header=T, check.names = F)
      columnsToKeep <- c(T,colnames(test[,2:ncol(test)]) %in% algorithms)
      test <- test[,columnsToKeep]
      
      rightLimit <- test[nrow(test),1]
      fileName <- paste("./plots/ecdf",tm,"_",f,".png",sep="")
      png(fileName)
      if (tm == "NT"){
        xLabel <- "normalized time"
      }
      if (tm == "FE"){
        xLabel <- "evaluation"
      }
      plot(0,0, xlim = c(0,rightLimit), ylim=c(0,1),type="n", main=f, 
           xlab=xLabel, ylab="1%-ECDF")
      
      counter <- 1
      for (i in 2:(1+length(algorithms))){
        lines(test[,1], test[,i], col=algoToColor(algorithms[counter]), lwd=2 ,lty = algoToLineType(algorithms[counter]))
        counter <- counter + 1
      }
      legend("bottomright", 95, legend=toupper(algorithms2),
             col=sapply(algorithms,function(x){algoToColor(x)}), 
             lty=sapply(algorithms,function(x){algoToLineType(x)}), 
             lwd=2, cex=0.8)
      dev.off()
      
      ###############
      # PC
      ###############
      optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
      #optimalTime <- johnsonTimes[johnsonTimes$instanceNames==f,2]
      instanceData <- parseInstanceName(f)
      dfs <- list()
      #instanceData <- parseInstanceName(f)
      counter <- 1
      leftLimit <- 0
      rightLimit <- Inf
      
      ###### altes Zeichnen (über die einzelnen TM-Ordner)
      # 
      # for (algo in algorithms){
      #   fileName <- paste("./",tm,"/",f,"-",algo,sep="")
      # 
      #   data <- read.csv(fileName, check.names = F)
      #   data$makespan <- (data$makespan - optimalTime)/optimalTime
      #   
      #   if (leftLimit < data[1,1]){
      #     leftLimit <- data[1,1]
      #   }
      #   if (rightLimit > data[nrow(data),1]){
      #     rightLimit <- data[nrow(data),1]
      #   }
      #   dfs[[counter]] <- data
      #   counter <- counter + 1
      #   
      # }
      # 
      # worstValues <- c()
      # bestValues <- c()
      # rightNTBorder <- Inf
      # for (tempDf in dfs){
      #   if (rightNTBorder > tempDf[nrow(tempDf),1]){
      #     rightNTBorder <- tempDf[nrow(tempDf),1]
      #   }
      #   worstValues <- c(worstValues, tempDf[1,2])
      #   bestValues <- c(bestValues, tempDf[nrow(tempDf),2])
      # }
      # 
      # xMax <- rightNTBorder
      # 
      # worstValue <- max(worstValues, na.rm=T)
      
      #### neues Zeichnen (nicht so detailliert, aber konsistent mit den
      #### anderen Diagrammen oben)
      
      fileName <- paste("./pc",tm,"/",f,sep="")
      test <- read.csv(fileName, check.names = F)
      
      
      fileName <- paste("./plots/pc",tm,"_",f,".png",sep="")
      png(fileName)
      
      if (tm == "NT"){
        xLabel <- "normalized time"
      }
      if (tm == "FE"){
        xLabel <- "evaluation"
      }
      
      
      plot(0,0, xlim = c(0,test[nrow(test),1]), ylim = c(0,max(test[,-1],na.rm = T)*1.2), type="n", main=f, 
           xlab=xLabel, ylab="RPD (Makespan)")
      
      for (i in 2:(1+length(algorithms))){
        lines(test[,1], test[,i], col=algoToColor(algorithms[counter]), lwd=2 ,lty = algoToLineType(algorithms[counter]))
        counter <- counter + 1
      }
      legend("topright", 95, legend=toupper(algorithms2),
             col=sapply(algorithms,function(x){algoToColor(x)}), 
             lty=sapply(algorithms,function(x){algoToLineType(x)}), 
             lwd=2, cex=0.8)
      
      # 
      # plot(c(0, xMax), c(0,worstValue*1.2), type = "n", main = f,xlab=xLabel, ylab="rel. Abweichung")
      # counter <- 1
      # for (tempDf in dfs){
      #   lines(tempDf[,1], tempDf[,2], col=algoToColor(algorithms[counter]), lwd=2 ,lty = "solid")
      #   counter <- counter + 1
      # }
      # legend("topright", 95, legend=toupper(algorithms2),
      #        col=sapply(algorithms,function(x){algoToColor(x)}), lty="solid", lwd=2, cex=0.8)
      # 
      dev.off()
      
    }  
  }
}

