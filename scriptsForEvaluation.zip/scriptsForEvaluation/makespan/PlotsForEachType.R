# Plots machen

# f2total-100-m2const-bufm1-mid-127-1
# f2inter-50-m2const-bufcount-mid-1-2

bestFoundTimes <- read.csv("bestResults.csv")
####################################
iType <- 1

for (f in typeList[[iType]]){
	# Plotte ERT, ECDF, PC
	cat(".")
	for (tm in timeMeasures){
	  
	  ############
	  # ERT
	  ############
	  
	  test <- read.csv(paste("./ertTables",tm,"/",f,sep=""),header=T, check.names = F)
	  columnsToKeep <- c(T,colnames(test[,2:ncol(test)]) %in% algorithms)
	  test <- test[,columnsToKeep]

	  worstRel <- test$relAbweichung[nrow(test)]
	  # den höchsten Ordinatenwert ermitteln (ohne Inf)
	  highest <- max(
		apply(
		  test[,2:(1+length(algorithms))],
		  MARGIN = 2,FUN =
			function(x){
			  temp <- unique(sort(x, decreasing = T))
			  if (length(temp)==1){ #wenn sofort 0 erreicht, nimm 0
				return(temp)
			  } else {
				return(temp[2]) #sonst den Wert nach inf
			  }
			}
		)
	  )
	  fileName <- paste("./plots/ert",tm,"_",f,".png",sep="")
	  png(fileName)
	  if (tm == "NT"){
		yLabel <- "ERT(NT)"
	  }
	  if (tm == "FE"){
		yLabel <- "ERT(FE)"
	  }
	  plot(0,0, xlim = c(0,worstRel), ylim=c(0,highest),type="n", main=f,
		   xaxs="i",
		   xlab="RPD (Makespan)", ylab=yLabel)

	  counter <- 1
	  for (i in 2:(1+length(algorithms))){
		lines(test$relAbweichung, test[,i], col=algoToColor(colnames(test)[i]), lwd=2 ,lty = algoToLineType(colnames(test)[i]))
		counter <- counter + 1
	  }
	  legend("topright", 95, legend=toupper(algorithms2),
			 col=sapply(algorithms,function(x){algoToColor(x)}),
			 lty=sapply(algorithms,function(x){algoToLineType(x)}),
			 lwd=2, cex=0.8)
	  dev.off()
	  # ###############
	  # # ECDF
	  # ###############

	  test <- read.csv(paste("./ecdfTables",tm,"/",f,sep=""),header=T, check.names = F)
	  columnsToKeep <- c(T,colnames(test[,2:ncol(test)]) %in% algorithms)
	  test <- test[,columnsToKeep]

	  rightLimit <- test[nrow(test),1]
	  fileName <- paste("./plots/ecdf",tm,"_",f,".png",sep="")
	  png(fileName)
	  if (tm == "NT"){
		xLabel <- "normalized time"
	  }
	  if (tm == "FE"){
		xLabel <- "evaluation"
	  }
	  plot(0,0, xlim = c(0,rightLimit), ylim=c(0,1),type="n", main=f,
		   xlab=xLabel, ylab="1%-ECDF")

	  counter <- 1
	  for (i in 2:(1+length(algorithms))){
		lines(test[,1], test[,i], col=algoToColor(colnames(test)[i]), lwd=2 ,lty = algoToLineType(colnames(test)[i]))
		counter <- counter + 1
	  }
	  legend("bottomright", 95, legend=toupper(algorithms2),
			 col=sapply(algorithms,function(x){algoToColor(x)}),
			 lty=sapply(algorithms,function(x){algoToLineType(x)}),
			 lwd=2, cex=0.8)
	  dev.off()
	  
	  ###############
	  # PC
	  ###############
	  optimalTime <- bestFoundTimes[bestFoundTimes$instance==f,2]
	  #optimalTime <- johnsonTimes[johnsonTimes$instanceNames==f,2]
	  instanceData <- parseInstanceName(f)
	  dfs <- list()
	  #instanceData <- parseInstanceName(f)
	  counter <- 1
	  leftLimit <- 0
	  rightLimit <- Inf
	  
	  #### neues Zeichnen (nicht so detailliert, aber konsistent mit den
	  #### anderen Diagrammen oben)
	  
	  # f <- "f2total-100-m2const-bufm1-mid-130-2"
	  # f <- "f2inter-50-m2const-bufcount-mid-1-2"
	  fileName <- paste("./pc",tm,"/",f,sep="")
	  test <- read.csv(fileName, check.names = F)

	  fileName <- paste("./plots/pc",tm,"_",f,".pdf",sep="")
	  pdf(fileName)
	  
	  if (tm == "NT"){
		xLabel <- "normalized time"
	  }
	  if (tm == "FE"){
		xLabel <- "evaluation"
	  }
	  
	  plot(0,0, xlim = c(0,test[nrow(test),1]), ylim = c(0,max(test[,-1],na.rm = T)*1.2), type="n", main="", 
		   xlab=xLabel, ylab="",
		   cex.lab=1.7,
		   cex.axis=1.7)
	  title(ylab="RPD (Makespan)", line=2.8, cex.lab=1.7)
	  
	  for (i in 2:(length(algorithms)+1)){
		lines(test[,1], test[,i], col=algoToColor(colnames(test)[i]), lwd=3 ,lty = algoToLineType(colnames(test)[i]))
		counter <- counter + 1
	  }
	  legend("topright", 95, legend=toupper(algorithms2),
			 col=sapply(algorithms,function(x){algoToColor(x)}), 
			 lty=sapply(algorithms,function(x){algoToLineType(x)}), 
			 lwd=2, cex=1.3)
	  

	  dev.off()
	  
	}  
}



