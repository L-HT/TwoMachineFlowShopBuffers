# Johnson-Schwelle ermitteln

instanceNames <- list.files("./instances/")
johnsonValues <- c()
for (f in instanceNames){
  fullPath <- paste("./instances/", f, sep="")
  jobData <- read.csv(fullPath, header=T, stringsAsFactors=F)
  johnsonBound <- TwoMachineFlowShopEx::getJohnsonBound(jobData)
  
  johnsonValues <- c(johnsonValues, johnsonBound)
}
johnsonDF <- data.frame(instanceNames, johnsonValues)
colnames(johnsonDF)[2] <- "johnsonBounds"
write.csv(johnsonDF,quote = F, file = "johnsonBounds.csv",row.names=F)
