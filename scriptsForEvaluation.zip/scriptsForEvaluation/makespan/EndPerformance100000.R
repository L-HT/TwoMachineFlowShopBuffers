# End-Performance und Performance nach 10k Evaluationen ermitteln

instanceNames <- list.files("./instances")

endPerformanceDf <- data.frame(
  matrix(ncol=length(algorithms) + 1, nrow = length(instanceNames))
)
colnames(endPerformanceDf) <- c("instance",algorithms)
endPerformanceDf$instance <- instanceNames
                    
#  endPerformanceDf <- data.frame(instance=instanceNames, ncol=length(algorithms)+1,
#                        check.names = F)



parseInstanceName <- function(fileName){
  parts <- as.list(strsplit(fileName, "-")[[1]])
  names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber")
  if (length(parts) == 8){
    names(parts) <- c("bufferType", "numberOfJobs", "m2Type", "bufType", "constrainedness", "maxBufferSize", "instanceNumber",
                       "fileSuffix")
  }
  if (parts$bufferType == "f2inter"){
    parts$bufferType <- "intermediateBuffer"
  } else if (parts$bufferType == "f2total"){
    parts$bufferType <- "totalBuffer"
  }
  parts$numberOfJobs <- as.integer(parts$numberOfJobs)
  parts$maxBufferSize <- as.integer(parts$maxBufferSize)
  parts$instanceNumber <- as.integer(parts$instanceNumber)
  parts$runNumber <- as.integer(parts$runNumber)
  return(parts)
}
# Endperformance
for (f in instanceNames){
  timeLimit <- 0
  instanceData <- parseInstanceName(f)
  if (instanceData$numberOfJobs == 10){
    next
  }
  if (instanceData$numberOfJobs == 50){
    timeLimit <- 300
  }
  if (instanceData$numberOfJobs == 100){
    timeLimit <- 600
  }
  if (instanceData$numberOfJobs == 150){
    timeLimit <- 900
  }
  for (algo in algorithms){
    fullName <- paste("./AT/",f,"-",algo,sep="")
    test <- read.csv(fullName, header=T)
    if (any(test$absoluteTime >= timeLimit)){
      test <- test[test$absoluteTime >= timeLimit,]
      endPerformanceDf[endPerformanceDf$instance==f, algo] <- test[1,2]
    } else {
      endPerformanceDf[endPerformanceDf$instance==f, algo] <- test[nrow(test),2]
    }
    
  }
  cat(".")
}
write.csv(endPerformanceDf, "endPerformance.csv", row.names=F, quote=F)

###########################

# Performance nach 100 Schritten
performance10000Df <- data.frame(
  matrix(ncol=length(algorithms) + 1, nrow = length(instanceNames))
)
colnames(performance10000Df) <- c("instance",algorithms)
performance10000Df$instance <- instanceNames

for (f in instanceNames){
  instanceData <- parseInstanceName(f)
  if (instanceData$numberOfJobs == 10){
    next
  }
  
  for (algo in algorithms){
    fullName <- paste("./FE/",f,"-",algo,sep="")
    test <- read.csv(fullName, header=T)
    if (any(test$evaluation >= 100000)){
      test <- test[test$evaluation >= 100000,]
      performance10000Df[performance10000Df$instance==f, algo] <- test[1,2]
    } else {
      performance10000Df[performance10000Df$instance==f, algo] <- test[nrow(test),2]
    }
    
  }
  cat(".")
}
write.csv(performance10000Df, "performance100000.csv", row.names=F, quote=F)
