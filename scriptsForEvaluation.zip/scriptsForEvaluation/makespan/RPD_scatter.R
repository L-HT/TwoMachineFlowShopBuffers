# Boxplots zeichnen
# Update: ergeben hier keinen Sinn, da wir gepaarte Stichproben

algoToColor <- function(algo){
  if (grepl("dabc",algo)){
    return("#d7191c")
  }
  if (grepl("hvns",algo)){
    return("#fdae61")
  }
  if (algo == "acols" || algo=="acols-lowEva"){
    return("#abdda4")
  }
  if (algo == "ils" || algo == "ils-cut" || algo == "ils-neh"){
    return("#2b83ba")
  }
  return("black")
}

endQuality <- read.csv("endPerformance.csv", check.names = F)
boxplot(endQuality[,-1])

endQuality50 <- endQuality[grepl("-50-", endQuality$instance),]
endQuality100 <- endQuality[grepl("-100-", endQuality$instance),]
endQuality150 <- endQuality[grepl("-150-", endQuality$instance),]

boxplot(endQuality50[,-1])

# also eher: scatter plot:

bestResults <- read.csv("bestResults.csv", check.names = F)

# Sortierung checken
if (all(bestResults$instance == endQuality$instance)){
  for (i in 2:ncol(endQuality)){
    endQuality[,i] <- endQuality[,i] / bestResults$bestValue
  }
}

worstValue <- max(endQuality[,-1])
worstValueX <- 1.026
worstValueY <- 1.01

pdf("rpdScatter.pdf")
plot(c(1,worstValue), c(1,worstValue), xlim = c(1,worstValueX), ylim = c(1, worstValueY), 
     col = "#AAAAAA", type="l", xlab="", ylab="",
     cex.lab=1.7,
     cex.axis=1.7)

title(ylab="RPD (2BF-ILS)", line=2.8, cex.lab=1.7)
title(xlab="RPD", cex.lab=1.7)

for (algo in algorithms){
  if (algo != "ils-neh"){
    myPch <- 19
    if (grepl("tuned", algo)){
      myPch <- 9
    }
    
    xVector <- endQuality[,algo]
    xVector <- sapply(xVector, function(x){min(x, runif(1, -0.001, 0.0003) + worstValueX)})
    points(xVector, endQuality[,"ils-neh"], xlim = c(1,worstValue), ylim = c(1, worstValue), 
           col = algoToColor(algo), pch=myPch
    )
  }
}

algorithms_withoutILS <- c("hvns", "dabc", "acols-lowEva", "dabc-tuned", "hvns-tuned")
algorithms2_withoutILS <-  c("hvns", "dabc", "aco", "dabc-t", "hvns-t")

legend("topleft", 95, legend=toupper(algorithms2_withoutILS),
       col=sapply(algorithms_withoutILS,function(x){algoToColor(x)}), 
       pch=sapply(algorithms_withoutILS,function(x){if(algoToLineType(x)=="solid"){19}else{9}}), 
       cex=1.3)
dev.off()

# Normalität der Daten prüfen
