# relative Flächeninhalte der einzelnen Kurven berechnen

pcNT <- read.csv("pcAreaNT", header=T, stringsAsFactors = F)
pcFE <- read.csv("pcAreaFE", header=T, stringsAsFactors = F)

ecdfNT <- read.csv("ecdfAreaNT", header=T, stringsAsFactors = F)
ecdfFE <- read.csv("ecdfAreaFE", header=T, stringsAsFactors = F)

ertNT <- read.csv("ertAreaNT", header=T, stringsAsFactors = F)
ertFE <- read.csv("ertAreaFE", header=T, stringsAsFactors = F)

calculateRel <- function(test, lessIsBetter = TRUE){
  penalty <- 3
  for (i in 1:nrow(test)){
    myVector <- as.numeric(test[i, -1])
    if (lessIsBetter){
      best = min(myVector)
      if (best == 0){
        #myVector[myVector != 0] <- penalty
        #myVector[myVector == 0] <- 1
        myVector <- myVector + 1
        best <- 1
      }
      test[i,-1] <- myVector/best
    } else {
      best = max(unique(myVector))
      names(myVector) <- NULL
      if (any(myVector == 0)){
        badIndices <- which(myVector == 0)
        scores <- sort(unique(as.numeric(myVector)))
        zeroReplace <- scores[2]
        myVector[badIndices] <- zeroReplace
        result <- best/myVector
        result[badIndices] <- result[badIndices] + penalty
      } else {
        result <- rep(best, length(myVector)) / as.numeric(myVector)
      }
      
      test[i,-1] <- result
    }
    
  }
  return(test)
}

pcNT <- calculateRel(pcNT)
write.csv(pcNT, "pcNT_rel.csv", row.names=F)
pcFE <- calculateRel(pcFE)
write.csv(pcFE, "pcFE_rel.csv", row.names=F)

ecdfNT <- calculateRel(ecdfNT, lessIsBetter = FALSE)
write.csv(ecdfNT, "ecdfNT_rel.csv", row.names=F)
ecdfFE <- calculateRel(ecdfFE, lessIsBetter = FALSE)
write.csv(ecdfFE, "ecdfFE_rel.csv", row.names=F)

ertNT <- calculateRel(ertNT)
write.csv(ertNT, "ertNT_rel.csv", row.names=F)
ertFE <- calculateRel(ertFE)
write.csv(ertFE, "ertFE_rel.csv", row.names=F)




