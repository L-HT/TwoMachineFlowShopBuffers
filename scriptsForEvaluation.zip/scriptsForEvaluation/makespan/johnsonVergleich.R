johnson <- read.csv("johnsonBounds.csv", stringsAsFactors=F)
best <- read.csv("bestResults.csv", stringsAsFactors=F)[,1:2]

best$johnson <- johnson$johnsonBounds
best <- best[best$bestValue == best$johnson,]
best$type <- 0

for (i in 1:nrow(best)){
  best$type[i] <- getTypeOfInstance(best$instance[i])
}

best <- best[,c(1,2,4)]
write.csv(best,"johnsonFoundInstances.csv",row.names=F)

instances <- list.files("./instancesClean/")
