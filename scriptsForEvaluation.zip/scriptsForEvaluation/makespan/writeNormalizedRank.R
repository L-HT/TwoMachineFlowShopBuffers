# normalisierte Ränge berechnen

pcFE <- read.csv("pcFE_rel.csv", check.names = F)
pcNT <- read.csv("pcNT_rel.csv", check.names = F)

ertFE <- read.csv("ertFE_rel.csv", check.names = F)
ertNT <- read.csv("ertNT_rel.csv", check.names = F)

ecdfFE <- read.csv("ecdfFE_rel.csv", check.names = F)
ecdfNT <- read.csv("ecdfNT_rel.csv", check.names = F)

# folgende Normalisierung:
# jede Zeile bekommt ein Ranking, dann
# wird mit dem Flächeninhalt in dieser Zelle verglichen und immer das Minimum genommen
# so wird das Ranking nicht durch Ausreißer zu stark beeinflusst
# und kleine Differenzen werden weiterhin berücksichtigt
# wird so etwas fairer

df_list <- list(pcFE, pcNT, ertFE, ertNT, ecdfFE, ecdfNT)
for (k in 1:length(df_list)){
  myDf <- df_list[[k]]
  for (i in 1:nrow(myDf)){
    myRow <- myDf[i,-1]
    myRank <- rank(myRow, ties.method = "min")
    for (j in 1:length(myRow)){
      myRow[j] <- min(myRow[j], myRank[j])
    }
    myDf[i,-1] <- myRow
  }
  df_list[[k]] <- myDf
}

write.csv(df_list[[1]], "pcFE_rank.csv", quote=F, row.names=F)
write.csv(df_list[[2]], "pcNT_rank.csv", quote=F, row.names=F)

write.csv(df_list[[3]], "ertFE_rank.csv", quote=F, row.names=F)
write.csv(df_list[[4]], "ertNT_rank.csv", quote=F, row.names=F)

write.csv(df_list[[5]], "ecdfFE_rank.csv", quote=F, row.names=F)
write.csv(df_list[[6]], "ecdfNT_rank.csv", quote=F, row.names=F)

