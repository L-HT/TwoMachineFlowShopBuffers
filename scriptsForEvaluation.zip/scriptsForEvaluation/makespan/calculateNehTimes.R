
# laufe durch NEH und schreibe DF
nehFiles <- list.files("./NEH")
meanValues <- c()
instanceNames <- c()
for (f in nehFiles){
  myData <- as.numeric(readLines(paste("./NEH/", f, sep="")))
  instanceName <- substr(f, 1, nchar(f)-4)
  meanValues <- c(meanValues, mean(myData))
  instanceNames <- c(instanceNames, instanceName)
  
}
nehDF <- data.frame(instanceNames, meanValues)
write.csv(nehDF,quote = F, file = "nehTimes.csv",row.names=F)

############################

nehDF <- data.frame(instanceNames, meanValues=1)


write.csv(nehDF,quote = F, file = "nehTimes.csv",row.names=F)
