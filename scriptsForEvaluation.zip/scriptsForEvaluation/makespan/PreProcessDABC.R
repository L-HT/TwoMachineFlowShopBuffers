# AVI vorverarbeiten

ALL_FILES <- list.files("COMBINEDRESULTS/")

DABC_FILES <- ALL_FILES[grepl("dabc",ALL_FILES)]

counter <- 0
for (f in DABC_FILES){
  fileName <- paste("./COMBINEDRESULTS/",f,sep="")
  test <- read.csv(fileName, header=F)
  result <- test[0,]
  
  #Kopf schreiben
  # fe_seq <- seq(from=10,to=test[1,1],by = 10)
  # time_seq <- seq(from=0,to=test[1,2],len=length(fe_seq))
  # test_df <- data.frame(V1=fe_seq, V2=time_seq,V3=1,V4=.Machine$integer.max)
  # result <- rbind(result, test_df)
  
  nn <- max(which(test$V3 == 1))
  for (i in (1):(nn-1)){
    fe_seq <- seq(from=test[i,1],to=test[i+1,1],by = 10)
    time_seq <- seq(from=test[i,2],to=test[i+1,2],len=length(fe_seq))
    test_df <- data.frame(V1=fe_seq, V2=time_seq,V3=test[i,3],V4=test[i,4])
    result <- rbind(result, test_df)
  }
  result <- rbind(result, test[(nn):nrow(test),])
  result_m <- as.matrix(result)
  write.table(result_m, fileName, col.names = F, row.names=F, sep=",")
  counter <- counter + 1
  if (counter %% 10 == 0){
    cat(".")
  }
}
