# Umtauschen der Namenspositionen, damit Run-Number am Ende steht
ALL_RESULTS <- list.files("./COMBINEDRESULTS/")
setwd("./COMBINEDRESULTS/")
for (f in ALL_RESULTS){
  
  partialStrings <- strsplit(f, "-")[[1]]
  if (length(partialStrings) >= 10){
    newName <- paste(partialStrings[c(1:8,10,9)], collapse="-")
    file.rename(f, newName)
  }
}
  
setwd("../")
