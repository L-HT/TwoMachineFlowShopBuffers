# statistischen Test machen, ob Performance danach wirklich besser ist

endQualityDf <- read.csv("endQualityTime.csv", stringsAsFactors = F)

perf1 <- endQualityDf[,2]
perf2 <- endQualityDf[,4]

# perf2 (nehMod) soll kleiner sein als perf1 (nehStandard)
# also soll perf1 größer sein als perf2
endTest <- BSDA::SIGN.test(perf1, perf2, alternative = "greater")

print(endTest)

instanceNames <- list.files("./instances") 
typeList <- list()

# Typ 1 (interM2ConstBufCount)
typeList[[1]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("inter", instanceNames)]

# Typ 2 (interM2ConstBufM1)
typeList[[2]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("inter", instanceNames)]

#Typ 3 (totalM2ConstBufCount)
typeList[[3]] <- instanceNames[grepl("m2const-bufcount", instanceNames) & grepl("total", instanceNames)]

# Typ 4 (totalM2ConstBufM1)
typeList[[4]] <- instanceNames[grepl("m2const-bufm1", instanceNames) & grepl("total", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[5]] <- instanceNames[grepl("small", instanceNames)]
typeList[[6]] <- instanceNames[grepl("mid", instanceNames)]
typeList[[7]] <- instanceNames[grepl("big", instanceNames)]

# Typ 5-7 (Konstante mid small big)
typeList[[8]] <- instanceNames[grepl("bufcount", instanceNames)]
typeList[[9]] <- instanceNames[grepl("bufm1", instanceNames)]


############################

numberOfTests <-  length(typeList)
instanceTypes <- 1:length(typeList)

resultDf <- data.frame(type = 1:9, p = 0.0, significant="", stringsAsFactors = F)

for (iType in instanceTypes){
  sub <- endQualityDf[endQualityDf$instanceName %in% typeList[[iType]],]
  
  perf1 <- sub[,2]
  perf2 <- sub[,4]
  
  endTest <- BSDA::SIGN.test(perf1, perf2, alternative = "greater")
  resultDf[iType, 2] <- endTest$p.value
  if (endTest$p.value < 0.05){
    resultDf[iType, 3] <- "-"
  } 
  if (endTest$p.value < 0.05 / numberOfTests){
    resultDf[iType, 3] <- "**"
  } 
}

write.csv(resultDf,paste("pValuesTime.csv",sep=""),quote = T)

