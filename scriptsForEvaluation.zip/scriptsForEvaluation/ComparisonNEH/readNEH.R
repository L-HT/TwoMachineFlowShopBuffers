# NEH-Ergebnisse einlesen und in ein DF schreiben

instanceNames <- list.files("instances/")

results <- list.files("output/")

nehFiles <- results[grepl("neh", results)]

meanValues <- c()
evalValues <- c()
qualityValues <- c()
instanceNames <- c()
for (f in nehFiles){
  myData <- as.numeric(readLines(paste("./output/", f, sep="")))
  instanceName <- substr(f, 1, nchar(f)-4)
  meanValues <- c(meanValues, mean(myData[1:10]))
  instanceNames <- c(instanceNames, instanceName)
  
  evalValues <- c(evalValues, myData[11])
  qualityValues <- c(qualityValues, myData[12])
  
}
nehDF <- data.frame(instanceName=instanceNames, meanTime=meanValues, evals=evalValues, quality=qualityValues)
write.csv(nehDF,quote = F, file = "nehData.csv",row.names=F)

###############################
