# ein Paired-Scatter-Plot, der Eval-Verteilung aufzeigt

# normalverteilte Zeiten
endQualityTime_normal <- read.csv("/endQualityTime_normal.csv", stringsAsFactors = F)
endQualityTime_normal$isNormal <- TRUE

endQualityTime <- read.csv("./endQualityTime.csv", stringsAsFactors = F)
endQualityTime$isNormal <- FALSE

endQualityTime50 <- endQualityTime[grepl("-50-", endQualityTime$instanceName),]
endQualityTime150 <- endQualityTime[grepl("-150-", endQualityTime$instanceName),]

algoToColor <- function(algo){
  if (grepl("dabc",algo)){
    return("#d7191c")
  }
  if (grepl("hvns",algo)){
    return("#fdae61")
  }
  if (algo == "acols" || algo=="acols-lowEva"){
    return("#abdda4")
  }
  if (algo == "ils" || algo == "ils-cut" || algo == "ils-neh"){
    return("#2b83ba")
  }
  return("black")
}

# beide Tabellen zusammen

combinedTable <- rbind(endQualityTime, endQualityTime_normal) 
combinedTable <- combinedTable[,-c(3,5)]
combinedTable
combinedTable$numberOfJobs <- sapply(as.character(combinedTable$instanceName), FUN=function(x){
  if (grepl("-50-",x)){return("a")}
  if (grepl("-100-",x)){return("b")}
  if (grepl("-150-",x)){return("c")}
  return("0")
}, USE.NAMES = F)
combinedTable <- combinedTable[,-1]


# Konvertierung in das long-Format
df_mNEH <- combinedTable[,-c(1)]

df_mNEH <- df_mNEH[,c(2,3,1)]

library(reshape2)
df_mNEH_m <- melt(df_mNEH, id.vars = c("isNormal","numberOfJobs"), measure.vars = c("timeUntilImprovement"))
df_mNEH_m <- df_mNEH_m[,-3]


color1 <- "#2b83ba"
color2 <- "#80d8ff"
colorRed <- "#d7191c"

pdf("./NEHVergleichBoxplot.pdf")
boxplot(df_mNEH_m$value ~ df_mNEH_m$isNormal + df_mNEH_m$numberOfJobs, data = df_mNEH_m,
        at = c(1,2,4,5,7,8), 
        names = c("","","","","",""),
        col=c(color1, color2),
        xaxs = FALSE, pch=4, xaxt="n",
        cex.axis=1.7,
        cex=1.7,
        cex.lab=1.7,
        lwd=2)

title(ylab="Evaluations", line=2.8, cex.lab=1.7)


lines(c(0.3,2.7), c(1274, 1274), col=colorRed, lwd=3)
lines(c(3.3,5.7), c(5049, 5049), col=colorRed, lwd=3)
lines(c(6.3,8.7), c(11324, 11324), col=colorRed, lwd=3)

axis(side=1, at=c(1.5, 4.5, 7.5), tick=F, labels = c("50 jobs", "100 jobs", "150 jobs"), cex.axis=1.7)
legend("topleft", fill = c(color1, color2), legend = c("uniform","normal"), cex=1.7)

dev.off()

#x-Achse-Ticks entfernen, yAchse: Evaluations, alles dicker?
