# Zeittabellen
instanceNames <- list.files("instances/")

nehDf <- read.csv("nehData.csv")
endQualityDf <- nehDf[,c("instanceName","evals")]
endQualityDf$initialTime <- 0
endQualityDf$timeUntilImprovement <- 0
endQualityDf$difference <- 0

for (f in instanceNames){
  
  goalQuality <- nehDf[nehDf$instanceName==f, "quality"]
  
  avgDf <- read.table(paste("./avgOutputExtended/", f, sep=""), header=T, sep=",", dec=".")
  
  improvedIndices <- which(avgDf$makespan <= goalQuality)
  if (length(improvedIndices) > 0){
    firstBetter <- min(improvedIndices)
    firstBetterTime <- avgDf[firstBetter, 1]
  } else {
    firstBetterTime <- Inf
  }
  endQualityDf[endQualityDf$instanceName==f, "initialTime"] <- avgDf[1, 1]
  endQualityDf[endQualityDf$instanceName==f, "timeUntilImprovement"] <- firstBetterTime
  endQualityDf[endQualityDf$instanceName==f, "difference"] <- firstBetterTime - avgDf[1, 1]
  cat(".")
}

write.table(endQualityDf, file = "endQualityTime.csv", sep=",", dec=".", row.names=F)