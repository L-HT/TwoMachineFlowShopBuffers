# Zeit bis zur Verbesserung plotten
instanceNames <- list.files("instances/")

#instanceNames <- c("f2inter-150-m2const-bufcount-mid-1-3",
#  "f2total-150-m2const-bufm1-mid-126-3")

nehDf <- read.csv("nehData.csv")
endQualityDf <- read.csv("endQualityTime.csv")
for (f in instanceNames){
  
  numberOfEvaluation <- nehDf[nehDf$instanceName==f, "evals"]
  numberOfEvaluationMod <- endQualityDf[endQualityDf$instanceName==f, "timeUntilImprovement"]
  
  nehNotReached <- FALSE
  if (is.infinite(numberOfEvaluationMod)){
    numberOfEvaluationMod <- 1*numberOfEvaluation
    nehNotReached <- TRUE
  }
  
  nehQuality <- nehDf[nehDf$instanceName == f, "quality"]
  avgDf <- read.table(paste("./avgOutputExtended/", f, sep=""), sep=",", dec=".", header=T)
  fileName <- paste("plots/",f,sep="")
  
  rightLimit <- max(numberOfEvaluation, numberOfEvaluationMod)
  png(fileName,width = 480, height=480)
  plot(avgDf[,1], avgDf[,2], 
       xlim=c(0, rightLimit*1.1), "l", 
       col="#2b83ba",
       ylim=c(0.95*min(nehQuality, min(avgDf$makespan, na.rm = T)), 
              1.05*max(nehQuality, max(avgDf$makespan, na.rm = T))
              ),
       xlab="evaluation", #main=f, 
       ylab="", lwd=2.5,
       cex.axis=1.7,
       cex.lab=1.7,
       xaxp=c(0,15000,6))
  title(ylab="makespan", line=2.8, cex.lab=1.7)
  
  points(avgDf[1,1], avgDf[1,2], pch = 4, cex=2)

  if (!nehNotReached){
    points(numberOfEvaluationMod, nehQuality, pch = 1, cex=2)
  }
  abline(h = nehQuality, lty="dashed")
  abline(v = numberOfEvaluation, lty="dashed")
  dev.off()
  cat(".")
}
