ALL_RESULTS <- list.files("./outputILS/")
setwd("./outputILS/")
for (f in ALL_RESULTS){
  
  partialStrings <- strsplit(f, "-")[[1]]
  if (length(partialStrings) >= 11){
    newName <- paste(partialStrings[c(1:9,11,10)], collapse="-")
    file.rename(f, newName)
  }
}

setwd("../")
