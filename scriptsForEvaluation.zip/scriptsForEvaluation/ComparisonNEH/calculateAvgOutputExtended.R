# avgOutput berechnen von ILS bezüglich Zeit
instanceNames <- list.files("instances/")

nehDf <- read.csv("nehData.csv")
endQualityDf <- nehDf[,c(1,2)]
endQualityDf$initialTime <- 0
endQualityDf$timeUntilImprovement <- 0
endQualityDf$difference <- 0

for (f in instanceNames){
  

  # erstmal alles aus ILS einlesen und mitteln
  dfs <- list()
  minEval <- 0
  rightLimit <- Inf
  for (runNumber in 1:10){
    fileName <- paste("outputILS/",f,"-ils-neh-", runNumber, sep="")
    test <- read.table(fileName, sep = ",", dec=".", header = F)
    #test <- test[test$V4 <= goalQuality,]
    dfs[[runNumber]] <- test
    
    if (test[1,1] > minEval){
      print(paste("from ", minEval, " to ", test[1,1], sep=""))
      minEval <- test[1,1]
    }
    
    if (rightLimit > test[nrow(test), 1]){
      rightLimit <- test[nrow(test), 1]
    }
  }
  
  avgDf <- data.frame(evaluation = seq(from=minEval,to=rightLimit,by=10), makespan=0)
  for (i in 1:nrow(avgDf)){
    values <- c()
    for (runNumber in 1:10){
      values <- c(values, dfs[[runNumber]][i,4])
    }
    avgDf[i, 2] <- mean(values)
  }

  write.table(avgDf, file = paste("./avgOutputExtended/", f, sep=""), sep=",", dec=".", row.names = F)
  
}
