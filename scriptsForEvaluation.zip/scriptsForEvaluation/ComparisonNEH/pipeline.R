# die ganze Pipeline
options(stringsAsFactors=F)

# nur, falls nötig
source("renameCombinedResults.R")

# NEH-Daten einlesen und in Df schreiben
source("readNEH.R")

# avgOutput berechnen und in Ordner schreiben
source("calculateAvgOutputExtended.R")

# avgOutput berechnen und in Ordner schreiben
source("writeTimeUntilImprovement.R")

# Plots erstellen
source("plotTimeUntilImprovement.R")

# Plots erstellen
source("createBoxplot.R")

# statistischen Test machen
source("statisticalTestTime.R")

